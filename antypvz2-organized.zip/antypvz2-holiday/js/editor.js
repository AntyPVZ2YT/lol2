(() => {
  const $ = (id) => document.getElementById(id);
  const fileInput = $('save-file'), fileInfo = $('file-info'), status = $('editor-status');
  const validation = $('validation-message'), exportButton = $('export-button');
  const resourceStatus = $('resource-status');
  const MAX_AMOUNT = 2012500000;
  const MAX_PLANT_LEVEL = 20;
  const MAX_PLANT_MASTERY = 200;
  const MAX_PLANT_SEEDS = 10000000;
  const resourceFields = { coins: 'c', gems: 'g', gauntlets: 't', mints: 'm', fuel: 'pf', perk: 'pt' };
  const STANDARD_POWERUPS = ['powerupwizardfinger','poweruppinchzombie','powerupflickzombie','powerupsnowball','powerupflamethrower','powerupvasebreakerreveal','powerupvasebreakerbutter','powerupvasebreakermove','powerupbeghouledshuffle','powerupbeghouledshovel','powerupbeghouledwizardfinger'];
  const POWERUP_LABELS = { powerupwizardfinger:'Wizard Finger', poweruppinchzombie:'Pinch', powerupflickzombie:'Flick', powerupsnowball:'Snowball', powerupflamethrower:'Flame', powerupvasebreakerreveal:'Vasebreaker Reveal', powerupvasebreakerbutter:'Vasebreaker Butter', powerupvasebreakermove:'Vasebreaker Move', powerupbeghouledshuffle:'Beghouled Shuffle', powerupbeghouledshovel:'Beghouled Shovel', powerupbeghouledwizardfinger:'Beghouled Wizard Finger' };
  // English display names verified against en.pvsz2.ru full RTID list.
  const PLANT_RTID_LABELS = {
    'akee': 'A.K.E.E.',
    'aloe': 'Aloe',
    'applemortar': 'Apple Mortar',
    'banana': 'Banana Launcher',
    'bloomerang': 'Bloomerang',
    'bloominghearts': 'Blooming Heart',
    'blover': 'Blover',
    'bombegranate': 'Bombegranate',
    'bonkchoy': 'Bonk Choy',
    'bowlingbulb': 'Bowling Bulb',
    'cabbagepult': 'Cabbage-pult',
    'cactus': 'Cactus',
    'caulipower': 'Caulipower',
    'celerystalker': 'Celery Stalker',
    'chardguard': 'Chard Guard',
    'cherrybomb': 'Cherry Bomb',
    'chilibean': 'Chili Bean',
    'chomper': 'Chomper',
    'citron': 'Citron',
    'coconutcannon': 'Coconut Cannon',
    'coldsnapdragon': 'Cold Snapdragon',
    'dandelion': 'Dandelion',
    'dusklobber': 'Dusk Lobber',
    'empea': 'E.M.Peach',
    'electricblueberry': 'Electric Blueberry',
    'electriccurrant': 'Electric Currant',
    'electricpeashooter': 'Electric Peashooter',
    'endurian': 'Endurian',
    'escaperoot': 'Escape Root',
    'explodeonut': 'Explode-o-nut',
    'firepeashooter': 'Fire Peashooter',
    'fumeshroom': 'Fume-shroom',
    'garlic': 'Garlic',
    'ghostpepper': 'Ghost Pepper',
    'goldbloom': 'Gold Bloom',
    'goldleaf': 'Gold Leaf',
    'grapeshot': 'Grapeshot',
    'gravebuster': 'Grave Buster',
    'grimrose': 'Grimrose',
    'guacodile': 'Guacodile',
    'hollyknight': 'Holly Barrier',
    'homingthistle': 'Homing Thistle',
    'hotdate': 'Hot Date',
    'hotpotato': 'Hot Potato',
    'hurrikale': 'Hurrikale',
    'hypnoshroom': 'Hypno-shroom',
    'iceburg': 'Iceberg Lettuce',
    'imitater': 'Imitater',
    'holonut': 'Infi-nut',
    'intensivecarrot': 'Intensive Carrot',
    'jackolantern': "Jack O' Lantern",
    'jalapeno': 'Jalapeno',
    'kernelpult': 'Kernel-pult',
    'kiwibeast': 'Kiwibeast',
    'laserbean': 'Laser Bean',
    'lavaguava': 'Lava Guava',
    'lightningreed': 'Lightning Reed',
    'lilypad': 'Lily Pad',
    'magnetshroom': 'Magnet-shroom',
    'magnifyinggrass': 'Magnifying Grass',
    'melonpult': 'Melon-pult',
    'missiletoe': 'Missile Toe',
    'moonflower': 'Moonflower',
    'nightshade': 'Nightshade',
    'parsnip': 'Parsnip',
    'peapod': 'Pea Pod',
    'peanut': 'Pea-nut',
    'peashooter': 'Peashooter',
    'pepperpult': 'Pepper-pult',
    'perfumeshroom': 'Perfume-shroom',
    'phatbeet': 'Phat Beet',
    'potatomine': 'Potato Mine',
    'powerlily': 'Power Lily',
    'primalpeashooter': 'Primal Peashooter',
    'primalpotatomine': 'Primal Potato Mine',
    'primalsunflower': 'Primal Sunflower',
    'primalwallnut': 'Primal Wall-nut',
    'puffshroom': 'Puff-shroom',
    'redstinger': 'Red Stinger',
    'repeater': 'Repeater',
    'xshot': 'Rotobaga',
    'sapfling': 'Sap-fling',
    'shadowshroom': 'Shadow-shroom',
    'shrinkingviolet': 'Shrinking Violet',
    'snapdragon': 'Snapdragon',
    'snowpea': 'Snow Pea',
    'solartomato': 'Solar Tomato',
    'spikerock': 'Spikerock',
    'spikeweed': 'Spikeweed',
    'splitpea': 'Split Pea',
    'sporeshroom': 'Spore-shroom',
    'springbean': 'Spring Bean',
    'squash': 'Squash',
    'stallia': 'Stallia',
    'starfruit': 'Starfruit',
    'strawburst': 'Strawburst',
    'stunion': 'Stunion',
    'sunbean': 'Sun Bean',
    'sunshroom': 'Sun-shroom',
    'sunflower': 'Sunflower',
    'sweetpotato': 'Sweet Potato',
    'tallnut': 'Tall-nut',
    'tanglekelp': 'Tangle Kelp',
    'threepeater': 'Threepeater',
    'thymewarp': 'Thyme Warp',
    'powerplant': 'Tile Turnip',
    'toadstool': 'Toadstool',
    'torchwood': 'Torchwood',
    'twinsunflower': 'Twin Sunflower',
    'wallnut': 'Wall-nut',
    'wasabiwhip': 'Wasabi Whip',
    'wintermelon': 'Winter Melon',
    'witchhazel': 'Witch Hazel',
    'filamint': 'Fila-mint',
    'reinforcemint': 'Reinforce-mint',
    'bombardmint': 'Bombard-mint',
    'containmint': 'Contain-mint',
    'armamint': 'Arma-mint',
    'spearmint': 'Spear-mint',
    'peppermint': 'Pepper-mint',
    'shadowpeashooter': 'Shadow Peashooter',
    'slingpea': 'Sling Pea',
    'poisonpeashooter': 'Goo Peashooter',
    'wintermint': 'Winter-mint',
    'enchantmint': 'Enchant-mint',
    'appeasemint': 'Appease-mint',
    'snappea': 'Snap Pea',
    'ailmint': 'Ail-mint',
    'enforcemint': 'Enforce-mint',
    'concealmint': 'Conceal-mint',
    'zoybeanpod': 'Zoybean Pod',
    'enlightenmint': 'Enlighten-mint',
    'dazeychain': 'Dazey Chain',
    'electricitea': 'Electrici-tea',
    'blastberry': 'Blastberry Vine',
    'imppear': 'Imp Pear',
    'pokra': 'Pokra',
    'pyrevine': 'Pyre Vine',
    'icebloom': 'Ice Bloom',
    'pumpkin': 'Pumpkin',
    'ultomato': 'Ultomato',
    'dartichoke': 'Dartichoke',
    'shinevine': 'Shine Vine',
    'gumnut': 'Gumnut',
    'tumbleweed': 'Tumbleweed',
    'olivepit': 'Olive Pit',
    'puffball': 'Puffball',
    'explodeovine': 'Explode-o-Vine',
    'murkadamia': 'Murkadamia Nut',
    'turkeypult': 'Turkey-pult',
    'headbutter': 'Headbutter Lettuce',
    'boingsetta': 'Boingsetta',
    'stickybombrice': 'Stickybomb Rice',
    'hocus': 'Hocus Crocus',
    'gloomvine': 'Gloom Vine',
    'draftodil': 'Draftodil',
    'pvine': 'Pea Vine',
    'boomflower': 'Boom Balloon Flower',
    'inferno': 'Inferno',
    'solarsage': 'Solar Sage',
    'noctarine': 'Noctarine',
    'powervine': 'Power Vine',
    'heathseeker': 'Heath Seeker',
    'iceweed': 'Iceweed',
    'tigergrass': 'Tiger Grass',
    'teleportatomine': 'Teleportato Mine',
    'blockoli': 'Blockoli',
    'buttercup': 'Buttercup',
    'bramblebush': 'Bramble Bush',
    'rhubarbarian': 'Rhubarbarian',
    'megagatling': 'Mega Gatling Pea',
    'levitater': 'Levitater',
    'tombtangler': 'Tomb Tangler',
    'vamporcini': 'Vamporcini',
    'meteorflower': 'Meteor Flower',
    'chillypepper': 'Chilly Pepper',
    'waterrabbit': 'Bun Chi',
    'buzzbutton': 'Buzz Button',
    'boomberry': 'BoomBerry',
    'seaflora': 'SeaFlora',
    'maybee': 'MayBee',
    'scaredyshroom': 'Scaredy-shroom',
    'bamboospartan': 'Bamboo Spartan',
    'sundewtangler': 'Sundew Tangler',
    beansprout:'Bean Sprout', cranjelly:'Cran Jelly', buduhboom:"Bud'uh Boom", dragonbruit:'Dragon Bruit', electricpeel:'Electric Peel', guardshroom:'Guard-shroom', aquavine:'Aqua Vine', mangofier:'Mangofier', blastspinner:'Blast Spinner', blazeleaf:'Blaze Leaf', frostbonnet:'Frost Bonnet', znakelily:'Znake Lily', sweetheartsnare:'Sweetheart Snare', hammeruit:'Hammeruit', cornfettipopper:'Corn-fetti Popper', seashooter:'Seashooter', devourbloom:'Devour Bloom', sourshot:'Sour Shot', brainstem:'Brain Stem', blazingknight:'Blazing Knight', sakura:'Sakura', voltsnapdragon:'Volt Snapdragon', thornwhip:'Thorn Whip', scorchoak:'Scorch Oak', cactalog:'Cactalog', baneberry:'Baneberry' 
  };
  let originalBytes = null, parsed = null, profile = null, profileEntry = null, profileEntries = [], activeProfileIndex = 0, fieldNodes = {}, powerupNodes = [], plantNodes = [], powerupsArrayNode = null;
  const PLANT_NUMERIC_ID_SEQUENCE = Array.isArray(window.ANTY_PLANT_NUMERIC_ID_SEQUENCE) ? window.ANTY_PLANT_NUMERIC_ID_SEQUENCE : [];
  const PLANT_NUMERIC_ID_LABELS = window.ANTY_PLANT_NUMERIC_ID_LABELS && typeof window.ANTY_PLANT_NUMERIC_ID_LABELS === 'object' ? window.ANTY_PLANT_NUMERIC_ID_LABELS : {};
  function normalizePlantKey(value) {
    return String(value ?? '').replace(/^RTID\(/i, '').replace(/\)$/,'').split('@')[0].split('.').pop().toLowerCase().replace(/[^a-z0-9]/g,'');
  }
  function plantNumericId(plantNode) {
    if (plantNode && Number.isSafeInteger(plantNode.value) && plantNode.value >= 0) return plantNode.value;
    const key = normalizePlantKey(plantNode?.value);
    if (/^\d+$/.test(key)) return Number(key);
    return null;
  }
  function plantRtidDisplay(plantNode) {
    if (!plantNode) return '—';
    const raw = String(plantNode.value ?? '');
    if (/^RTID\(/i.test(raw)) return raw;
    const key = normalizePlantKey(raw);
    return key ? `RTID(${key}@PlantTypes)` : raw || '—';
  }
  function seedTargetFor(plantNode, numericId) {
    if (!Number.isSafeInteger(numericId)) return null;
    const key = normalizePlantKey(plantNode?.value);
    if (key === 'starfruit') return Math.max(0, numericId - 5);
    if (key === 'dazeychain') return Math.max(0, numericId - 10);
    return numericId;
  }

  let originalForm = null, inspectionReport = null;

  function validAmount(input) {
    if (input.value.trim() === '') return false;
    const n = Number(input.value);
    return Number.isSafeInteger(n) && n >= 0 && n <= MAX_AMOUNT;
  }

  function readVarint(bytes, state, end) {
    let value = 0, shift = 0;
    for (let count = 0; count < 10; count++) {
      if (state.p >= end) throw new Error("Unexpected end while reading an RTON number.");
      const b = bytes[state.p++];
      value += (b & 0x7f) * (2 ** shift);
      if (!Number.isSafeInteger(value)) throw new Error("Number exceeds JavaScript's safe integer range.");
      if ((b & 0x80) === 0) return value;
      shift += 7;
    }
    throw new Error("Invalid or oversized RTON number.");
  }

  function encodeVarint(value) {
    const out = [];
    let n = value;
    do {
      let b = n % 128;
      n = Math.floor(n / 128);
      if (n > 0) b |= 0x80;
      out.push(b);
    } while (n > 0);
    return out;
  }

  function parseRTON(bytes) {
    if (bytes.length < 12) throw new Error("File is too small to be an RTON save.");
    if (String.fromCharCode(...bytes.slice(0, 4)) !== "RTON") throw new Error("This file does not begin with the RTON signature.");
    if (bytes[4] !== 1 || bytes[5] !== 0 || bytes[6] !== 0 || bytes[7] !== 0) throw new Error("Unsupported RTON header version.");
    const footerAt = bytes.length - 4;
    if (String.fromCharCode(...bytes.slice(footerAt)) !== "DONE") throw new Error('The expected "DONE" footer is missing.');
    const state = { p: 8, ascii: [], utf8: [] };

    function need(n) {
      if (!Number.isSafeInteger(n) || n < 0 || state.p + n > footerAt) throw new Error("RTON field extends beyond the file boundary.");
    }
    function take(n) {
      need(n);
      const value = bytes.slice(state.p, state.p + n);
      state.p += n;
      return value;
    }
    function string(utf, cache) {
      if (utf) readVarint(bytes, state, footerAt); // UTF-8 character count
      const length = readVarint(bytes, state, footerAt);
      const value = new TextDecoder("utf-8", { fatal: false }).decode(take(length));
      if (cache) (utf ? state.utf8 : state.ascii).push(value);
      return value;
    }
    function chunk(path) {
      need(1);
      const start = state.p;
      const token = bytes[state.p++];
      const node = (value, children = null) => ({ value, start, end: state.p, token, path, children });
      const rawInt = (length, signed) => {
        const part = take(length);
        let value = 0;
        for (let i = 0; i < length; i++) value += part[i] * (256 ** i);
        if (signed && value >= (2 ** (length * 8 - 1))) value -= 2 ** (length * 8);
        return value;
      };
      if (token === 0x00) return node(false);
      if (token === 0x01) return node(true);
      if (token === 0x08) return node(rawInt(1, true));
      if (token === 0x0a) return node(rawInt(1, false));
      if (token === 0x10) return node(rawInt(2, true));
      if (token === 0x12) return node(rawInt(2, false));
      if (token === 0x20) return node(rawInt(4, true));
      if (token === 0x26) return node(rawInt(4, false));
      if (token === 0x22) {
        const part = take(4);
        return node(new DataView(part.buffer, part.byteOffset, 4).getFloat32(0, true));
      }
      if (token === 0x40) return node(rawInt(8, true));
      if (token === 0x46) return node(rawInt(8, false));
      if (token === 0x42) {
        const part = take(8);
        return node(new DataView(part.buffer, part.byteOffset, 8).getFloat64(0, true));
      }
      if ([0x09,0x0b,0x11,0x13,0x21,0x27,0x41,0x47].includes(token)) return node(0);
      if (token === 0x23 || token === 0x43) return node(0.0);
      if ([0x24,0x28,0x44,0x48].includes(token)) return node(readVarint(bytes, state, footerAt));
      if ([0x25,0x29,0x45,0x49].includes(token)) {
        let n = readVarint(bytes, state, footerAt);
        if (n % 2) n = -(n + 1);
        return node(n / 2);
      }
      if (token === 0x81) return node(string(false, false));
      if (token === 0x82) return node(string(true, false));
      if (token === 0x83) {
        need(1);
        const subset = bytes[state.p++];
        if (subset === 0) return node("RTID()");
        if (subset === 2) {
          readVarint(bytes, state, footerAt);
          const len = readVarint(bytes, state, footerAt);
          const name = new TextDecoder().decode(take(len));
          const u2 = readVarint(bytes, state, footerAt);
          const u1 = readVarint(bytes, state, footerAt);
          const id = rawInt(4, false).toString(16);
          return node(`RTID(${u1}.${u2}.${id}@${name})`);
        }
        if (subset === 3) {
          readVarint(bytes, state, footerAt); const n1 = readVarint(bytes, state, footerAt);
          const s1 = new TextDecoder().decode(take(n1));
          readVarint(bytes, state, footerAt); const n2 = readVarint(bytes, state, footerAt);
          const s2 = new TextDecoder().decode(take(n2));
          return node(`RTID(${s2}@${s1})`);
        }
        throw new Error("Unknown RTON reference (RTID) subtype.");
      }
      if (token === 0x84) return node(null);
      if (token === 0x85) return parseObject(path, start, token);
      if (token === 0x86) {
        need(1);
        if (bytes[state.p++] !== 0xfd) throw new Error("Malformed RTON array start.");
        const count = readVarint(bytes, state, footerAt);
        if (count > 2000000) throw new Error("Unreasonable RTON array size.");
        const children = [];
        for (let i = 0; i < count; i++) children.push(chunk(path.concat(i)));
        need(1);
        if (bytes[state.p++] !== 0xfe) throw new Error("Malformed RTON array end.");
        return node(children.map(child => child.value), children);
      }
      if (token === 0x90) return node(string(false, true));
      if (token === 0x91) {
        const index = readVarint(bytes, state, footerAt);
        if (index >= state.ascii.length) throw new Error("Invalid RTON string-cache reference.");
        return node(state.ascii[index]);
      }
      if (token === 0x92) return node(string(true, true));
      if (token === 0x93) {
        const index = readVarint(bytes, state, footerAt);
        if (index >= state.utf8.length) throw new Error("Invalid RTON UTF-8 cache reference.");
        return node(state.utf8[index]);
      }
      if (token === 0xff) return node("__RTON_END__");
      throw new Error(`Unsupported RTON token 0x${token.toString(16).padStart(2, "0")} at byte ${start}.`);
    }
    function parseObject(path, start, token) {
      const value = {};
      const children = [];
      while (state.p < footerAt) {
        const keyNode = chunk(path.concat("<key>"));
        if (keyNode.value === "__RTON_END__") return { value, start, end: state.p, token, path, children };
        if (typeof keyNode.value !== "string") throw new Error("RTON object contains a non-string key.");
        const valueNode = chunk(path.concat(keyNode.value));
        value[keyNode.value] = valueNode.value;
        children.push({ key: keyNode.value, keyNode, valueNode });
      }
      throw new Error("RTON object is missing its end marker.");
    }

    const root = parseObject([], 8, null);
    if (state.p !== footerAt) throw new Error("Unexpected bytes remain before the RTON footer.");
    return { root, bytes, footerAt };
  }

  function child(node, key) {
    return node && node.children && node.children.find(item => item.key === key)?.valueNode;
  }


  function getChild(node, key) {
    return node && node.children && node.children.find(item => item.key === key)?.valueNode;
  }
  function getObjectChildren(node) { return node && Array.isArray(node.children) ? node.children : []; }
  function findProfileEntries(parsedSave) {
    const objects = getChild(parsedSave.root, 'objects');
    if (!objects || !Array.isArray(objects.children)) throw new Error('No objects array was found in this RTON save.');
    return objects.children.filter(entry => getChild(entry, 'objclass')?.value === 'PlayerInfo' && getChild(entry, 'objdata'));
  }
  function findProfile(parsedSave, index = 0) {
    const found = findProfileEntries(parsedSave);
    if (!found.length) throw new Error('No PlayerInfo profile was found in this RTON save.');
    if (!found[index]) throw new Error(`Profile ${index + 1} was not found.`);
    return getChild(found[index], 'objdata');
  }
  function profileName(entry, index) {
    const name = getChild(getChild(entry, 'objdata'), 'n')?.value;
    return typeof name === 'string' && name.trim() ? name : `Profile ${index + 1}`;
  }
  function populateProfileSelect() {
    const select = $('profile-select'); select.replaceChildren();
    profileEntries.forEach((entry, index) => {
      const option = document.createElement('option'); option.value = String(index); option.textContent = `${index + 1}. ${profileName(entry, index)}`; select.append(option);
    });
    select.disabled = profileEntries.length === 0;
    select.value = String(activeProfileIndex);
    $('add-profile-button').disabled = profileEntries.length === 0 || profileEntries.length >= 5;
    $('add-profile-button').title = profileEntries.length >= 5 ? 'The game supports a maximum of 5 profiles.' : '';
    $('rename-profile-name').disabled = profileEntries.length === 0;
    $('rename-profile-button').disabled = profileEntries.length === 0; 
  }
  function loadProfileAt(index) {
    activeProfileIndex = index; profileEntry = profileEntries[index]; profile = getChild(profileEntry, 'objdata');
    if (!profile) throw new Error('Selected profile has no objdata.');
    fieldNodes = {}; powerupNodes = []; plantNodes = []; powerupsArrayNode = null;
    for (const id of Object.keys(resourceFields)) $(id).value = '';
    for (const [id,key] of Object.entries(resourceFields)) { fieldNodes[id] = requireIntField(getChild(profile,key),key); $(id).value = String(fieldNodes[id].value); }
    const plantsNode = getChild(profile,'p'), costumesNode = getChild(profile,'cos');
    $('plant-ids').value = arrayValues(plantsNode,'plants').join(', '); fieldNodes.plants = plantsNode;
    $('costume-ids').value = arrayValues(costumesNode,'costumes').join(', '); fieldNodes.costumes = costumesNode;
    renderPowerups(); renderPlantLevels();
    populateProfileSelect(); captureOriginalForm(); validateAll();
  }
  function encodeVarint(value) {
    const out = []; let n = value;
    do { let b = n % 128; n = Math.floor(n / 128); if (n > 0) b |= 0x80; out.push(b); } while (n > 0);
    return out;
  }
  function encodeInt(value) { return new Uint8Array([0x24, ...encodeVarint(value)]); }
  function encodeBool(value) { return new Uint8Array([value ? 0x01 : 0x00]); }
  function encodeIntArray(values) {
    const out = [0x86, 0xfd, ...encodeVarint(values.length)];
    for (const value of values) out.push(...encodeInt(value));
    out.push(0xfe); return new Uint8Array(out);
  }
  function encodeString(value) { const bytes=new TextEncoder().encode(value); return [0x81,...encodeVarint(bytes.length),...bytes]; }
  function encodePowerupArray(items) {
    const out=[0x86,0xfd,...encodeVarint(items.length)];
    for(const item of items) out.push(0x85,...encodeString('n'),...encodeString(item.name),...encodeString('i'),...encodeInt(item.count),0xff);
    out.push(0xfe); return new Uint8Array(out);
  }
  function replaceRanges(bytes, ranges) {
    const sorted = ranges.filter(r => r && r.replacement).slice().sort((a,b) => b.start - a.start);
    for (let i=1; i<sorted.length; i++) if (sorted[i-1].start < sorted[i].end) throw new Error('Overlapping edits detected; export stopped.');
    let result = bytes.slice();
    for (const r of sorted) {
      const next = new Uint8Array(result.length - (r.end-r.start) + r.replacement.length);
      next.set(result.slice(0,r.start),0); next.set(r.replacement,r.start); next.set(result.slice(r.end),r.start+r.replacement.length); result=next;
    }
    return result;
  }
  function requireIntField(node, label) {
    if (!node || !Number.isSafeInteger(node.value) || node.value < 0) throw new Error(`Could not verify numeric field ${label}.`);
    return node;
  }
  function parseIdList(value, label) {
    const parts = value.trim() === '' ? [] : value.split(',').map(s => s.trim());
    const values = parts.map(s => {
      if (!/^\d+$/.test(s)) throw new Error(`${label} must contain only comma-separated whole-number IDs.`);
      const n = Number(s); if (!Number.isSafeInteger(n) || n > MAX_AMOUNT) throw new Error(`${label} contains an ID outside the supported range.`); return n;
    });
    if (new Set(values).size !== values.length) throw new Error(`${label} contains duplicate IDs; remove duplicates before exporting.`);
    return values;
  }
  function arrayValues(node, label) {
    if (!node || !Array.isArray(node.children) || !Array.isArray(node.value)) throw new Error(`Could not verify the ${label} array.`);
    if (!node.children.every(n => Number.isSafeInteger(n.value) && n.value >= 0 && n.value <= MAX_AMOUNT)) throw new Error(`${label} contains entries that are not numeric IDs.`);
    return node.value.slice();
  }
  function addNumberInput(label, value, className='compact-number', maxValue=MAX_AMOUNT) {
    const wrap = document.createElement('div'); wrap.className='field-group '+className;
    const id = 'dyn-'+Math.random().toString(36).slice(2);
    const lab = document.createElement('label'); lab.htmlFor=id; lab.textContent=label;
    const input=document.createElement('input'); input.id=id; input.type='number'; input.min='0'; input.max=String(maxValue); input.step='1'; input.inputMode='numeric'; input.value=String(value);
    wrap.append(lab,input); return {wrap,input};
  }
  function renderPowerups() {
    const host=$('powerups-list'); host.replaceChildren(); powerupNodes=[];
    powerupsArrayNode=getChild(profile,'pr');
    if (!powerupsArrayNode || !Array.isArray(powerupsArrayNode.children)) { host.textContent='No power-up array was found in this save.'; return; }
    const existing=new Map();
    for (const [idx,entry] of powerupsArrayNode.children.entries()) {
      const nameNode=getChild(entry,'n'), countNode=getChild(entry,'i');
      if (nameNode && typeof nameNode.value==='string' && countNode && Number.isSafeInteger(countNode.value) && countNode.value>=0) existing.set(nameNode.value,{node:countNode,index:idx,count:countNode.value});
    }
    const names=[...STANDARD_POWERUPS,...[...existing.keys()].filter(name=>!STANDARD_POWERUPS.includes(name))];
    for (const name of names) {
      const found=existing.get(name); const item=addNumberInput(POWERUP_LABELS[name] || name, found ? found.count : 0);
      item.wrap.classList.add('powerup-item');
      const presets=document.createElement('div'); presets.className='powerup-presets'; presets.setAttribute('aria-label',`${POWERUP_LABELS[name] || name} presets`);
      for (const [label,amount] of [['1K',1000],['100K',100000],['1M',1000000],['100M',100000000],['1B',1000000000],['Max',MAX_AMOUNT]]) {
        const button=document.createElement('button'); button.type='button'; button.className='powerup-preset'; button.textContent=label; button.addEventListener('click',()=>{ item.input.value=String(amount); validateAll(); status.textContent=`${POWERUP_LABELS[name] || name} set to ${amount.toLocaleString()}. Export to save the change.`; }); presets.append(button);
      }
      item.wrap.append(presets); host.append(item.wrap);
      powerupNodes.push({node:found?.node || null,input:item.input,name,index:found?.index ?? -1});
    }
    if (!powerupNodes.length) host.textContent='No power-up fields were recognized.';
  }

  function renderPlantLevels() {
    plantNodes = [];
    const host = $('plant-levels-list');
    const count = $('plant-count');
    if (!host) return;
    host.replaceChildren();
    const list = getChild(profile, 'plis');
    if (!list || !Array.isArray(list.children)) {
      host.textContent = 'No supported plant-record list was found in this profile. The save can still be inspected and other supported fields edited.';
      if (count) count.textContent = 'No plant records detected.';
      return;
    }

    for (const [index, entry] of list.children.entries()) {
      const plant = getChild(entry, 'p');
      const level = getChild(entry, 'l');
      const seeds = getChild(entry, 'x');
      const mastery = getChild(entry, 'm');
      if (!plant || !level || !seeds || !mastery ||
          !Number.isSafeInteger(level.value) || !Number.isSafeInteger(seeds.value) ||
          !Number.isSafeInteger(mastery.value) || level.value < -1 || seeds.value < 0 || mastery.value < 0) continue;

      const plantLabel = typeof plant.value === 'string' ? plant.value : String(plant.value);
      const normalizedPlantLabel = normalizePlantKey(plantLabel);
      // Seed packets are a quantity, not a plant identifier. Never use x to
      // identify a plant: doing so caused repeated values (for example 36)
      // to label unrelated records as Marigold. Resolve from the plant RTID / p
      // field first, then use the verified record-order ID only as a fallback.
      const idFromPlantField = plantNumericId(plant);
      const numericId = idFromPlantField;
      // IDs 217 and above are resource/variation records, not editable plants.
      if (numericId != null && numericId >= 217) continue;
      const plantDisplayName = PLANT_RTID_LABELS[normalizedPlantLabel]
        || (numericId != null ? PLANT_NUMERIC_ID_LABELS[String(numericId)] : null)
        || (Number.isSafeInteger(plant.value) ? `Plant ID ${plant.value}` : 'Unknown plant');

      const row = document.createElement('div');
      row.className = 'plant-row';
      row.dataset.plantSearch = `${plantLabel} ${plantDisplayName} ${numericId ?? ''} ${index + 1} ${index}`.toLowerCase();
      row.dataset.level = String(level.value);
      row.dataset.seeds = String(seeds.value);
      row.dataset.mastery = String(mastery.value);
      row.dataset.numericId = numericId == null ? '' : String(numericId);

      const heading = document.createElement('div');
      heading.className = 'plant-row-heading';
      const title = document.createElement('strong');
      title.className = 'plant-id';
      title.textContent = plantDisplayName || 'Unknown plant';
      heading.append(title);
      row.append(heading);

      const grid = document.createElement('div');
      grid.className = 'field-grid';
      const idInput = addNumberInput('Numeric ID', numericId == null ? '' : numericId, 'plant-numeric-id-field');
      idInput.input.readOnly = numericId != null;
      idInput.input.title = numericId == null
        ? 'Plant ID could not be resolved from this record.'
        : 'Detected plant ID from the plant record; seed-packet quantity is stored separately.';
      const levelInput = addNumberInput('Plant level', level.value, 'plant-level-field', MAX_PLANT_LEVEL);
      levelInput.input.min = '-1';
      const seedInput = addNumberInput('Seed packets', seeds.value, 'plant-seed-field', MAX_PLANT_SEEDS);
      const masteryInput = addNumberInput('Mastery', mastery.value, 'plant-mastery-field', MAX_PLANT_MASTERY);
      grid.append(idInput.wrap, levelInput.wrap, seedInput.wrap, masteryInput.wrap);
      row.append(grid);

      host.append(row);

      for (const input of [idInput.input, levelInput.input, seedInput.input, masteryInput.input]) {
        input.addEventListener('input', () => {
          const currentId = idInput.input.value.trim() === '' ? null : Number(idInput.input.value);
          row.dataset.numericId = Number.isSafeInteger(currentId) ? String(currentId) : '';
          row.dataset.level = levelInput.input.value;
          row.dataset.seeds = seedInput.input.value;
          row.dataset.mastery = masteryInput.input.value;
          filterPlantRows();
        });
      }

      plantNodes.push({
        plant, level, seeds, mastery, index,
        numericIdInput: idInput.input,
        numericId,
        inputs: {
          'Plant level': levelInput.input,
          'Seed packets': seedInput.input,
          'Mastery': masteryInput.input
        }
      });
    }

    if (!plantNodes.length) {
      host.textContent = 'The plant list exists, but no records with the expected numeric level, seed, and mastery fields were recognized. No plant records were changed.';
    }
    if (count) count.textContent = `${plantNodes.length} supported plant record${plantNodes.length === 1 ? '' : 's'} detected.`;
    filterPlantRows();
  }


  function filterPlantRows() {
    const query = ($('plant-search')?.value || '').trim().toLowerCase();
    const filter = $('plant-filter')?.value || 'all';
    const rows = [...$('plant-levels-list').querySelectorAll('.plant-row')];
    let shown = 0;
    rows.forEach(row => {
      const matchesQuery = !query || row.dataset.plantSearch.includes(query);
      const matchesFilter =
        filter === 'all' ||
        (filter === 'leveled' && Number(row.dataset.level) > 0) ||
        (filter === 'seeds' && Number(row.dataset.seeds) > 0) ||
        (filter === 'mastery' && Number(row.dataset.mastery) > 0) ||
        (filter === 'numeric' && row.dataset.numericId !== '');
      row.hidden = !(matchesQuery && matchesFilter);
      if (!row.hidden) shown++;
    });
    const count = $('plant-count');
    if (count && rows.length) count.textContent = `${shown} of ${rows.length} plant records shown.`;
  }

  function captureOriginalForm() {
    originalForm={};
    for (const id of [...Object.keys(resourceFields),'plant-ids','costume-ids']) originalForm[id]=$(id).value;
    originalForm.powerups=powerupNodes.map(p=>p.input.value);
    originalForm.plants=plantNodes.map(p=>({level:p.inputs['Plant level'].value,seeds:p.inputs['Seed packets'].value,mastery:p.inputs['Mastery'].value}));
  }
  function validateAll(showMessage=true) {
    if (!originalBytes || !parsed || !profile) { exportButton.disabled=true; if(showMessage) validation.textContent='Choose a supported save file to begin.'; return false; }
    try {
      for (const id of Object.keys(resourceFields)) { const input=$(id); if(!validAmount(input)) throw new Error(`${input.labels?.[0]?.textContent || id}: enter a whole number from 0 to ${MAX_AMOUNT}.`); }
      parseIdList($('plant-ids').value,'Plant IDs'); parseIdList($('costume-ids').value,'Costume IDs');
      for (const p of powerupNodes) if(!validAmount(p.input)) throw new Error(`Power-up ${p.name}: enter a whole number from 0 to ${MAX_AMOUNT}.`);
      for (const p of plantNodes) {
        const levelInput=p.inputs['Plant level']; const seedInput=p.inputs['Seed packets']; const masteryInput=p.inputs['Mastery'];
        const level=Number(levelInput.value), seeds=Number(seedInput.value), mastery=Number(masteryInput.value);
        if(!Number.isSafeInteger(level) || level < -1 || level > MAX_PLANT_LEVEL) throw new Error(`Plant level: enter a whole number from -1 to ${MAX_PLANT_LEVEL}.`);
        if(!Number.isSafeInteger(seeds) || seeds < 0 || seeds > MAX_PLANT_SEEDS) throw new Error(`Seed packets: enter a whole number from 0 to ${MAX_PLANT_SEEDS.toLocaleString()}.`);
        if(!Number.isSafeInteger(mastery) || mastery < 0 || mastery > MAX_PLANT_MASTERY) throw new Error(`Mastery: enter a whole number from 0 to ${MAX_PLANT_MASTERY}.`);
      }
      exportButton.disabled=false; if(showMessage) validation.textContent='All values are valid. Export will patch only supported fields.'; return true;
    } catch(e) { exportButton.disabled=true; if(showMessage) validation.textContent=e.message; return false; }
  }
  function clearEditor(clearFileSelection = true) {
    originalBytes=null; parsed=null; profile=null; profileEntry=null; profileEntries=[]; activeProfileIndex=0; fieldNodes={}; powerupNodes=[]; plantNodes=[]; powerupsArrayNode=null; originalForm=null;
    if (clearFileSelection) fileInput.value=''; fileInfo.textContent='No file selected yet.'; status.textContent='Select a supported save to inspect it locally.';
    if ($('resource-status')) $('resource-status').textContent='Load a save first.';
    for (const id of Object.keys(resourceFields)) $(id).value=''; $('plant-ids').value=''; $('costume-ids').value='';
    $('powerups-list').textContent='Load a save to show its power-ups.'; $('plant-levels-list').textContent='';
    validation.textContent='Choose a save file to begin.'; exportButton.disabled=true; $('profile-select').replaceChildren(new Option('Load a save first','0')); $('profile-select').disabled=true; $('add-profile-button').disabled=true; $('rename-profile-name').disabled=true; $('rename-profile-button').disabled=true; $('rename-profile-name').value='';
    inspectionReport = null;
  }
  function setInspector(fileStatus, size, format, count, summary, profileText) {
    const values = { 'inspector-status': fileStatus, 'inspector-size': size, 'inspector-format': format, 'inspector-count': count, 'inspector-summary': summary };
    for (const [id, value] of Object.entries(values)) { const node = $(id); if (node) node.textContent = value; }
    const profilesNode = $('inspector-profiles'); if (profilesNode) profilesNode.textContent = profileText;
  }
  function renderDiagnostics(items) {
    const node = $('inspector-diagnostics'); if (!node) return;
    node.replaceChildren();
    items.forEach(item => { const line = document.createElement('div'); line.className = 'inspector-diagnostic'; line.dataset.level = item.level || 'info'; line.textContent = `${item.level === 'good' ? '✓' : item.level === 'warning' ? '⚠' : '•'} ${item.text}`; node.append(line); });
  }
  async function sha256(bytes) {
    if (!globalThis.crypto?.subtle) return 'Unavailable in this browser context';
    const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
    return Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
  }
  function downloadInspectionReport() {
    if (!inspectionReport) return;
    const blob = new Blob([JSON.stringify(inspectionReport, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob); const link = document.createElement('a');
    link.href = url; link.download = 'antypvz2-save-inspection.json'; document.body.append(link); link.click(); link.remove(); URL.revokeObjectURL(url);
  }
  $('inspector-report-button')?.addEventListener('click', downloadInspectionReport);
  function renderInspectorProfiles(entries) {
    const node = $('inspector-profiles'); if (!node) return;
    node.replaceChildren();
    if (!entries.length) { node.textContent = 'No PlayerInfo profiles were detected.'; return; }
    entries.forEach((entry, index) => {
      const chip = document.createElement('span'); chip.className = 'inspector-profile-chip';
      chip.textContent = `${index + 1}. ${profileName(entry, index)}`; node.append(chip);
    });
  }
  // Apply the maximum supported value to every currency/resource and power-up at once.
  $('max-all-resources-powerups')?.addEventListener('click', () => {
    if (!profile) { status.textContent = 'Load a save first to apply the bulk maximum.'; return; }
    for (const id of Object.keys(resourceFields)) $(id).value = String(MAX_AMOUNT);
    for (const powerup of powerupNodes) powerup.input.value = String(MAX_AMOUNT);
    validateAll();
    status.textContent = 'All currencies, resources, and recognized power-ups set to Max. Export to save the changes.';
  });

  // Identical presets are available independently on each currency/resource field.
  document.querySelectorAll('.resource-preset').forEach(button => button.addEventListener('click', () => {
    const input = button.closest('.resource-item')?.querySelector('input[type="number"]');
    if (!input) return;
    input.value = button.dataset.amount;
    validateAll();
    const label = button.closest('.resource-item')?.querySelector('label')?.textContent || 'Resource';
    status.textContent = `${label} set to ${Number(input.value).toLocaleString()}. Export to save the change.`;
  }));

  fileInput.addEventListener('change', async () => {
    const file=fileInput.files && fileInput.files[0]; clearEditor(false); if(!file) return;
    const sizeText = file.size >= 1024 * 1024 ? `${(file.size / (1024 * 1024)).toFixed(2)} MB` : `${(file.size / 1024).toFixed(1)} KB`;
    setInspector('Checking…', sizeText, 'Not verified', '—', 'Reading and validating the file structure locally…', 'Profile detection is in progress.');
    let bytes = null, fingerprint = 'Unavailable in this browser context';
    try {
      if (file.size === 0) throw new Error('The selected file is empty.');
      bytes = new Uint8Array(await file.arrayBuffer());
      try { fingerprint = await sha256(bytes); } catch (_) { fingerprint = 'Could not calculate'; }
      const save=parseRTON(bytes); const entries=findProfileEntries(save);
      if (!entries.length) throw new Error('No PlayerInfo profile was found.');
      originalBytes=bytes; parsed=save; profileEntries=entries; activeProfileIndex=0; loadProfileAt(0);
      if (resourceStatus) resourceStatus.textContent = 'Save loaded. Edit each value independently or tap a preset under that value.';
      fileInfo.textContent=`${file.name} · ${sizeText} · RTON v1 · parsed locally, not uploaded.`;
      status.textContent=`Save recognized with ${profileEntries.length} profile(s). Edit locally; exports use the exact filename pp.dat.`;

      const names = entries.map((entry, index) => profileName(entry, index).trim().toLocaleLowerCase());
      const duplicates = names.filter((name, index) => names.indexOf(name) !== index);
      const diagnostics = [
        { level: 'good', text: 'RTON signature, supported header version, and DONE footer were verified.' },
        { level: 'good', text: 'The editor parsed the file and located PlayerInfo profile data.' },
        { level: file.name.toLowerCase().endsWith('.dat') ? 'good' : 'warning', text: file.name.toLowerCase().endsWith('.dat') ? 'Filename has a .dat extension.' : 'Filename does not end in .dat; confirm you selected the intended save.' },
        { level: entries.length > 5 ? 'warning' : 'good', text: `Detected ${entries.length} profile(s); the editor's profile manager supports up to 5.` },
        { level: duplicates.length ? 'warning' : 'good', text: duplicates.length ? 'Some profile names appear duplicated; review the profile list before editing.' : 'No duplicate profile names were detected.' },
        { level: fingerprint.startsWith('Unavailable') || fingerprint === 'Could not calculate' ? 'warning' : 'info', text: fingerprint.startsWith('Unavailable') || fingerprint === 'Could not calculate' ? 'SHA-256 fingerprint could not be calculated in this browser context.' : 'SHA-256 fingerprint calculated for later file comparison.' }
      ];

    } catch(e) {
      clearEditor(false); fileInfo.textContent=`${file.name} · ${sizeText}`; status.textContent=`Could not load this file: ${e.message}`; validation.textContent='No changes were made. Check that you selected the actual PvZ2 pp.dat save, not a ZIP, screenshot, or backup folder.'; if (resourceStatus) resourceStatus.textContent='The file was selected but could not be parsed. Try the original pp.dat file.';

      const diagnostics = [
        { level: 'warning', text: `Parsing failed: ${e.message}` },
        { level: file.size === 0 ? 'warning' : 'info', text: `Selected file size: ${file.size} bytes.` },
        { level: 'info', text: 'Editing is disabled because the file structure could not be verified.' }
      ];

    }
  });
  $('profile-select').addEventListener('change', () => {
    if (!originalBytes || !profileEntries.length) return;
    const nextIndex = Number($('profile-select').value);
    if (!Number.isInteger(nextIndex) || nextIndex === activeProfileIndex) return;
    try {
      const built = buildEditedSave();
      originalBytes = built.edited; parsed = parseRTON(originalBytes); profileEntries = findProfileEntries(parsed);
      loadProfileAt(nextIndex);
      status.textContent = `Now editing profile ${nextIndex + 1}: ${profileName(profileEntries[nextIndex], nextIndex)}. Changes to the previous profile are kept in memory.`;
    } catch (e) { $('profile-select').value = String(activeProfileIndex); status.textContent = `Could not switch profile: ${e.message}`; }
  });
  document.addEventListener('input', e => { if(e.target.matches('input,textarea')) validateAll(); });
  // Plant presets affect recognized plant records in the active profile only. They never add unrecognized records.
  document.querySelectorAll('.plant-preset').forEach(button => button.addEventListener('click', () => {
    if (!profile || !plantNodes.length) { status.textContent = 'Load a supported save first to apply a plant preset.'; return; }
    const preset = button.dataset.preset;
    for (const p of plantNodes) {
      const levelInput = p.inputs['Plant level'];
      const seedInput = p.inputs['Seed packets'];
      const masteryInput = p.inputs['Mastery'];
      if (preset === 'unlock') {
        levelInput.value = '1';
        if (Number(seedInput.value) < 1) seedInput.value = '1';
      } else if (preset === 'max-level') {
        levelInput.value = String(MAX_PLANT_LEVEL);
      } else if (preset === 'max-mastery') {
        levelInput.value = String(MAX_PLANT_LEVEL);
        masteryInput.value = String(MAX_PLANT_MASTERY);
      } else if (preset === 'level-one') {
        levelInput.value = '1';
        masteryInput.value = '0';
      }
      const row = levelInput.closest('.plant-row');
      if (row) {
        row.dataset.level = levelInput.value;
        row.dataset.seeds = seedInput.value;
        row.dataset.mastery = masteryInput.value;
      }
    }
    validateAll();
    const labels = { unlock: 'All recognized plant records set to level 1 with at least 1 seed packet', 'max-level': `All recognized plant records set to level ${MAX_PLANT_LEVEL}`, 'max-mastery': `All recognized plant records set to level ${MAX_PLANT_LEVEL} and mastery ${MAX_PLANT_MASTERY}`, 'level-one': 'All recognized plant records set to level 1 and mastery 0' };
    status.textContent = `${labels[preset] || 'Plant preset applied'}. Export to save the changes.`;
    filterPlantRows();
  }));

  // Enforce the global numeric ceiling across static and dynamically-created editor fields.
  document.addEventListener('change', e => {
    const input = e.target;
    if (!input.matches('input[type=number]')) return;
    input.min = '0'; input.max = String(MAX_AMOUNT); input.step = '1';
    const raw = input.value.trim();
    if (raw === '') { validateAll(); return; }
    const n = Number(raw);
    if (!Number.isFinite(n) || n < 0) input.value = '0';
    else if (n > MAX_AMOUNT) input.value = String(MAX_AMOUNT);
    // Keep fractional values visible so validation can explain the error instead of silently rounding.
    validateAll();
  });
  document.addEventListener('blur', e => {
    const input = e.target;
    if (!input.matches('input[type=number]') || input.value.trim() === '') return;
    const n = Number(input.value);
    if (Number.isFinite(n) && Number.isInteger(n)) input.value = String(Math.max(0, Math.min(MAX_AMOUNT, n)));
    validateAll();
  }, true);
  $('plant-search').addEventListener('input', () => { if(profile) filterPlantRows(); });
  $('plant-filter')?.addEventListener('change', () => { if(profile) filterPlantRows(); });
  function buildEditedSave() {
    if(!validateAll()) throw new Error(validation.textContent || 'Please fix invalid values first.');
    const ranges=[];
    for(const id of Object.keys(resourceFields)) { const n=fieldNodes[id], value=Number($(id).value); if(value!==n.value) ranges.push({start:n.start,end:n.end,replacement:encodeInt(value)}); }
    const newPlants=parseIdList($('plant-ids').value,'Plant IDs'); if(JSON.stringify(newPlants)!==JSON.stringify(fieldNodes.plants.value)) ranges.push({start:fieldNodes.plants.start,end:fieldNodes.plants.end,replacement:encodeIntArray(newPlants)});
    const newCostumes=parseIdList($('costume-ids').value,'Costume IDs'); if(JSON.stringify(newCostumes)!==JSON.stringify(fieldNodes.costumes.value)) ranges.push({start:fieldNodes.costumes.start,end:fieldNodes.costumes.end,replacement:encodeIntArray(newCostumes)});
    const powerupsNeedAdd=powerupNodes.some(p=>!p.node && Number(p.input.value)>0);
    if(powerupsNeedAdd) {
      if(powerupsArrayNode.children.length!==0) throw new Error('This save has a non-empty power-up list with an unrecognized missing type. To avoid losing extra data, adding missing power-ups is only enabled when the original list is empty.');
      const entries=powerupNodes.map(p=>({name:p.name,count:Number(p.input.value)})).filter(p=>p.count>0);
      ranges.push({start:powerupsArrayNode.start,end:powerupsArrayNode.end,replacement:encodePowerupArray(entries)});
    } else {
      for(const p of powerupNodes) if(p.node) { const value=Number(p.input.value); if(value!==p.node.value) ranges.push({start:p.node.start,end:p.node.end,replacement:encodeInt(value)}); }
    }
    for(const p of plantNodes) {
      const fields=[[p.level,p.inputs['Plant level']],[p.seeds,p.inputs['Seed packets']],[p.mastery,p.inputs['Mastery']]];
      for(const [node,input] of fields) { const value=Number(input.value); if(value!==node.value) ranges.push({start:node.start,end:node.end,replacement:encodeInt(value)}); }
    }

    const edited=replaceRanges(originalBytes,ranges); const verified=parseRTON(edited); const vp=findProfile(verified, activeProfileIndex);
    for(const [id,key] of Object.entries(resourceFields)) if(getChild(vp,key)?.value!==Number($(id).value)) throw new Error(`Verification failed for ${key}.`);
    if(JSON.stringify(arrayValues(getChild(vp,'p'),'plants'))!==JSON.stringify(newPlants)) throw new Error('Plant list verification failed.');
    if(JSON.stringify(arrayValues(getChild(vp,'cos'),'costumes'))!==JSON.stringify(newCostumes)) throw new Error('Costume list verification failed.');
    const verifiedPowerups=getChild(vp,'pr');
    for(const p of powerupNodes) { const match=verifiedPowerups?.children?.find(entry=>getChild(entry,'n')?.value===p.name); const expected=Number(p.input.value); if((match ? getChild(match,'i')?.value : 0)!==expected) throw new Error(`Power-up verification failed for ${p.name}.`); }
    const verifiedPlis=getChild(vp,'plis');
    for(const p of plantNodes) { const entry=verifiedPlis?.children?.[p.index]; if(getChild(entry,'l')?.value!==Number(p.inputs['Plant level'].value)||getChild(entry,'x')?.value!==Number(p.inputs['Seed packets'].value)||getChild(entry,'m')?.value!==Number(p.inputs['Mastery'].value)) throw new Error(`Plant record verification failed for ID ${p.plant.value}.`); }

    if (edited.length < 12 || String.fromCharCode(...edited.slice(0, 4)) !== 'RTON' || String.fromCharCode(...edited.slice(-4)) !== 'DONE') throw new Error('Export validation failed: the output signature or footer is invalid. No download was created.');
    return {edited, changedRanges:ranges.length};
  }
  async function downloadSave(bytes) {
    const blob = new Blob([bytes], { type: 'application/octet-stream' });
    const filename = 'pp.dat';

    // Prefer Web Share API on iOS / mobile (most reliable way to "save" a file)
    try {
      if (navigator.share && navigator.canShare) {
        const file = new File([blob], filename, { type: 'application/octet-stream' });
        if (navigator.canShare({ files: [file] })) {
          await navigator.share({ files: [file], title: filename });
          return;
        }
      }
    } catch (shareErr) {
      // User cancelled share or share failed — fall through to download
      if (shareErr && shareErr.name === 'AbortError') return;
    }

    // Standard download path
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    link.style.display = 'none';
    document.body.appendChild(link);
    link.click();
    link.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 2000);

    // iOS Safari sometimes ignores download= — open blob as last resort hint
    const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent) || (navigator.platform === 'MacIntel' && navigator.maxTouchPoints > 1);
    if (isIOS) {
      // Give the share sheet / Files app a moment; status already updated by caller
    }
  }
  exportButton.addEventListener('click', async () => {
    try {
      const result = buildEditedSave();
      const changeCount = result.changedRanges;
      const prompt = changeCount === 0
        ? 'No supported field changes were detected. Export a copy of this save as pp.dat anyway?'
        : `Safe Export Check\n\n${changeCount} field range(s) will be changed in the exported pp.dat.\n\nThe original imported file will not be overwritten. Keep a backup and only continue if these edits are intended. Game compatibility cannot be guaranteed.\n\nExport now?`;
      if (!window.confirm(prompt)) {
        status.textContent = 'Export cancelled. Your imported save has not been downloaded or overwritten.';
        return;
      }
      status.textContent = 'Preparing export…';
      await downloadSave(result.edited);
      status.textContent = `Export ready as pp.dat. Safe Export Check passed: ${changeCount} field range(s) changed. On iPhone use the share sheet → Save to Files. Keep your original backup.`;
    } catch(e) { status.textContent=`Export stopped: ${e.message}`; }
  });
  $('rename-profile-name').addEventListener('keydown', e => { if (e.key === 'Enter' && !$('rename-profile-button').disabled) $('rename-profile-button').click(); });
  $('profile-name').addEventListener('keydown', e => { if (e.key === 'Enter' && !$('add-profile-button').disabled) $('add-profile-button').click(); });
  $('rename-profile-button').addEventListener('click', () => {
    (async () => {
      try {
        if (!originalBytes || !profileEntries.length) throw new Error('Load a supported save first.');
        const name = $('rename-profile-name').value.trim();
        if (!name) throw new Error('Enter a new name for the active profile.');
        if (name.length > 40) throw new Error('Profile names must be 40 characters or fewer.');
        const built = buildEditedSave();
        const base = built.edited;
        const save = parseRTON(base);
        const entries = findProfileEntries(save);
        const entry = entries[activeProfileIndex];
        const nameNode = getChild(getChild(entry, 'objdata'), 'n');
        if (!nameNode || typeof nameNode.value !== 'string') throw new Error('The selected profile name field could not be verified; no download was created.');
        if (nameNode.value === name) throw new Error('That is already the active profile name.');
        const renamed = replaceRanges(base, [{start:nameNode.start, end:nameNode.end, replacement:new Uint8Array(encodeString(name))}]);
        const verified = parseRTON(renamed);
        const verifiedEntries = findProfileEntries(verified);
        if (verifiedEntries.length !== entries.length || profileName(verifiedEntries[activeProfileIndex], activeProfileIndex) !== name) throw new Error('The renamed profile did not pass verification; no download was created.');
        originalBytes = renamed; parsed = verified; profileEntries = verifiedEntries;
        loadProfileAt(activeProfileIndex);
        $('rename-profile-name').value = '';
        await downloadSave(renamed);
        status.textContent = `Renamed active profile to “${name}”. The updated save passed parsing and profile-count checks. On iPhone use the share sheet → Save to Files. Keep your original backup.`;
      } catch (e) { status.textContent = `Could not rename profile: ${e.message}`; }
    })();
  });

  $('add-profile-button').addEventListener('click', () => {
    (() => {
    try {
      if (!originalBytes || !profileEntry) throw new Error('Load a save first.');
      if (profileEntries.length >= 5) throw new Error('The game supports a maximum of 5 profiles. This save already has 5 profiles.');
      const name = $('profile-name').value.trim();
      if (!name) throw new Error('Enter a name for the new profile first.');
      if (name.length > 40) throw new Error('Profile names must be 40 characters or fewer.');
      const built = buildEditedSave(); const base = built.edited; const save = parseRTON(base); const entries = findProfileEntries(save);
      const sourceEntry = entries[activeProfileIndex]; if (!sourceEntry) throw new Error('Could not find the selected profile.');
      const sourceData = getChild(sourceEntry, 'objdata'); const nameNode = getChild(sourceData, 'n');
      const idNode = getChild(sourceData, 'i'), rsNode = getChild(sourceData, 'rs');
      if (!nameNode || typeof nameNode.value !== 'string' || !idNode || !Number.isSafeInteger(idNode.value) || !rsNode || !Number.isSafeInteger(rsNode.value)) throw new Error('This profile does not have the expected name and ID fields; profile creation was stopped safely.');
      const idValues = entries.flatMap(entry => { const data=getChild(entry,'objdata'); return [getChild(data,'i')?.value,getChild(data,'rs')?.value].filter(Number.isSafeInteger); });
      const newId = Math.max(Math.floor(Date.now()/1000), ...idValues) + 1;
      if (!Number.isSafeInteger(newId) || newId < 0) throw new Error('A safe unique profile ID could not be generated; no changes were exported.');
      let clone = base.slice(sourceEntry.start, sourceEntry.end);
      clone = replaceRanges(clone, [
        {start:nameNode.start-sourceEntry.start,end:nameNode.end-sourceEntry.start,replacement:new Uint8Array(encodeString(name))},
        {start:idNode.start-sourceEntry.start,end:idNode.end-sourceEntry.start,replacement:encodeInt(newId)},
        {start:rsNode.start-sourceEntry.start,end:rsNode.end-sourceEntry.start,replacement:encodeInt(newId)}
      ]);
      const objectsNode = getChild(save.root, 'objects'); if (!objectsNode || !Array.isArray(objectsNode.children)) throw new Error('The objects array could not be safely updated.');
      const arrayBytes = [0x86,0xfd,...encodeVarint(objectsNode.children.length+1)];
      for (const entry of objectsNode.children) {
        const entryBytes = base.subarray(entry.start, entry.end);
        for (let i = 0; i < entryBytes.length; i++) arrayBytes.push(entryBytes[i]);
      }
      for (let i = 0; i < clone.length; i++) arrayBytes.push(clone[i]);
      arrayBytes.push(0xfe);
      const combined = replaceRanges(base,[{start:objectsNode.start,end:objectsNode.end,replacement:new Uint8Array(arrayBytes)}]);
      const verified = parseRTON(combined), verifiedEntries = findProfileEntries(verified);
      if (verifiedEntries.length !== entries.length+1 || profileName(verifiedEntries[verifiedEntries.length-1],verifiedEntries.length-1) !== name) throw new Error('The new profile did not pass verification; no download was created.');
      originalBytes=combined; parsed=verified; profileEntries=verifiedEntries; activeProfileIndex=verifiedEntries.length-1;
      loadProfileAt(activeProfileIndex); $('profile-name').value='';
      status.textContent=`Added profile “${name}” by copying the selected profile. The change is kept in the editor; use Export as pp.dat when you are ready to save it.`;
    } catch(e) { status.textContent=`Could not add profile: ${e.message}`; }
    })();
  });
  clearEditor();
})();


