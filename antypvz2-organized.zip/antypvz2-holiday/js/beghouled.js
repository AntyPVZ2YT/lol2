(() => {
  'use strict';
  const SIZE=8, START_MOVES=30, KEY='antypvz2_beghouled_v1';
  const plants=[
    {name:'Peashooter',image:'images/Peashooter.png',placeholder:'🌱'},
    {name:'Sunflower',image:'images/Sunflower.png',placeholder:'🌻'},
    {name:'Cabbage-pult',image:'images/CabbagePult.png',placeholder:'🥬'},
    {name:'Marigold',image:'images/Marigold.png',placeholder:'🌼'},
    {name:'Wall-nut',image:'images/WallNut.png',placeholder:'🌰'},
    {name:'Snow Pea',image:'images/SnowPea.png',placeholder:'❄️'}
  ];
  const $=id=>document.getElementById(id);
  let board=[],selected=-1,score=0,moves=START_MOVES,matches=0,best=0,sound=true,locked=false,audioCtx=null,effectsVolume=0.35;
  const music=$('bg-music'),musicToggle=$('bg-music-toggle'),musicMute=$('bg-music-mute'),musicVolume=$('bg-music-volume');
  function updateMusic(){music.volume=Number(musicVolume.value)/100;musicToggle.textContent=music.paused?'▶ Play music':'Ⅱ Pause music';musicMute.textContent=music.muted?'🔇 Music muted':'🔊 Music on';musicMute.setAttribute('aria-pressed',String(music.muted));}
  musicToggle.addEventListener('click',async()=>{if(music.paused){try{await music.play()}catch(e){musicToggle.textContent='▶ Tap to play music';}}else music.pause();updateMusic();});
  musicMute.addEventListener('click',()=>{music.muted=!music.muted;updateMusic();});
  musicVolume.addEventListener('input',()=>{music.volume=Number(musicVolume.value)/100;if(music.volume>0)music.muted=false;updateMusic();});
  music.addEventListener('play',updateMusic);music.addEventListener('pause',updateMusic);updateMusic();
  function rand(){return Math.floor(Math.random()*plants.length)}
  function makeBoard(){board=Array.from({length:SIZE*SIZE},(_,i)=>{let v;do{v=rand()}while((i%SIZE>=2&&board[i-1]===v&&board[i-2]===v)||(i>=SIZE*2&&board[i-SIZE]===v&&board[i-SIZE*2]===v));return v})}
  function save(){try{localStorage.setItem(KEY,JSON.stringify({board,score,moves,matches,best,sound}))}catch(_){}}
  function load(){try{const s=JSON.parse(localStorage.getItem(KEY)||'null');if(s&&Array.isArray(s.board)&&s.board.length===SIZE*SIZE&&s.board.every(v=>Number.isInteger(v)&&v>=0&&v<plants.length)){board=s.board;score=Math.max(0,s.score|0);moves=Math.max(0,s.moves|0);matches=Math.max(0,s.matches|0);best=Math.max(0,s.best|0);sound=s.sound!==false;return true}}catch(_){}return false}
  function render(){ $('bg-board').innerHTML='';board.forEach((v,i)=>{const b=document.createElement('button');b.type='button';b.className='bg-tile'+(selected===i?' is-selected':'');const plant=plants[v];if(!plant){b.classList.add('bg-clearing');b.textContent='';b.title='Clearing match';b.setAttribute('aria-label','Clearing match');}else{if(plant.image){const img=document.createElement('img');img.src=plant.image;img.alt='';img.loading='lazy';img.decoding='async';img.draggable=false;img.onerror=()=>{img.remove();b.classList.add('bg-image-fallback');b.textContent=plant.placeholder||'🌱'};b.appendChild(img)}else{b.classList.add('bg-image-fallback');b.textContent=plant.placeholder||'🌱'}b.title=plant.name;b.setAttribute('aria-label',plant.name+(selected===i?', selected':''));}b.setAttribute('role','gridcell');b.disabled=locked||moves<=0;b.addEventListener('click',()=>choose(i));$('bg-board').appendChild(b)});$('bg-score').textContent=score.toLocaleString();$('bg-moves').textContent=moves;$('bg-best').textContent=best.toLocaleString();$('bg-matches').textContent=matches;$('bg-sound').textContent=sound?'🔊 Effects on':'🔇 Effects off';$('bg-sound').setAttribute('aria-pressed',String(sound));save()}
  function beep(freq=520){if(!sound)return;try{audioCtx=audioCtx||new(window.AudioContext||window.webkitAudioContext)();const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.frequency.value=freq;o.type='sine';g.gain.value=.10*effectsVolume;o.connect(g);g.connect(audioCtx.destination);o.start();g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+.12);o.stop(audioCtx.currentTime+.12)}catch(_){}}
  function findMatches(){const set=new Set();for(let r=0;r<SIZE;r++){let c=0;while(c<SIZE){let e=c+1;while(e<SIZE&&board[r*SIZE+e]===board[r*SIZE+c])e++;if(e-c>=3)for(let x=c;x<e;x++)set.add(r*SIZE+x);c=e}}for(let c=0;c<SIZE;c++){let r=0;while(r<SIZE){let e=r+1;while(e<SIZE&&board[e*SIZE+c]===board[r*SIZE+c])e++;if(e-r>=3)for(let x=r;x<e;x++)set.add(x*SIZE+c);r=e}}return set}
  const adjacent=(a,b)=>Math.abs(Math.floor(a/SIZE)-Math.floor(b/SIZE))+Math.abs(a%SIZE-b%SIZE)===1;
  async function resolve(){let chain=0;while(true){const hit=findMatches();if(!hit.size)break;chain++;matches++;score+=hit.size*10+(hit.size>=4?20:0)+(hit.size>=5?50:0);best=Math.max(best,score);hit.forEach(i=>board[i]=-1);render();beep(500+Math.min(hit.size,6)*70);await new Promise(r=>setTimeout(r,180));for(let c=0;c<SIZE;c++){let vals=[];for(let r=SIZE-1;r>=0;r--)if(board[r*SIZE+c]!==-1)vals.push(board[r*SIZE+c]);while(vals.length<SIZE)vals.push(rand());for(let r=SIZE-1;r>=0;r--)board[r*SIZE+c]=vals[SIZE-1-r]}render();await new Promise(r=>setTimeout(r,150));if(chain>30)break}locked=false;if(moves<=0){$('bg-message').textContent=`Game over! Final score: ${score.toLocaleString()}. Start a new game to play again.`}else $('bg-message').textContent='Nice match! Swap another pair of neighboring plants.';render()}
  async function choose(i){if(locked||moves<=0)return;if(selected<0){selected=i;render();return}if(selected===i){selected=-1;render();return}if(!adjacent(selected,i)){selected=i;render();return}const a=selected,b=i;selected=-1;[board[a],board[b]]=[board[b],board[a]];if(!findMatches().size){[board[a],board[b]]=[board[b],board[a]];$('bg-message').textContent='That swap did not make a match. Try another pair!';beep(180);render();return}moves--;locked=true;$('bg-message').textContent='Plant combo!';render();await resolve()}
  function newGame(){score=0;moves=START_MOVES;matches=0;selected=-1;locked=false;makeBoard();let safety=0;while(findMatches().size&&safety++<20){findMatches().forEach(i=>board[i]=rand())} $('bg-message').textContent='Fresh lawn! Match 3 or more plants.';render()}
  $('bg-new').addEventListener('click',newGame);$('bg-sound').addEventListener('click',()=>{sound=!sound;render();beep()});$('bg-reset').addEventListener('click',()=>{if(confirm('Clear your saved Beghouled progress and best score?')){localStorage.removeItem(KEY);best=0;newGame()}});
  if(!load()){makeBoard();while(findMatches().size){findMatches().forEach(i=>board[i]=rand())}}render();
})();
