(function(){
'use strict';
let HOLIDAY=window.AntyHoliday&&window.AntyHoliday.getActiveSeason?window.AntyHoliday.getActiveSeason():(window.AntyHoliday?window.AntyHoliday.getSeason():'normal');

const seasonColors = {
  normal: {accent:'#35ff70', accent2:'#b7ffd0'},
  halloween: {accent:'#ff8a24', accent2:'#ffcb66'},
  christmas: {accent:'#ed444e', accent2:'#a6f3c1'},
  easter: {accent:'#d879db', accent2:'#f4b5ee'},
  thanksgiving: {accent:'#e88a2b', accent2:'#ffd18a'},
  spring: {accent:'#ff6bcb', accent2:'#ffb3e6'},
  summer: {accent:'#ff8a1f', accent2:'#ffd36a'}
};
const sc = seasonColors[HOLIDAY] || seasonColors.normal;
document.documentElement.style.setProperty('--season-accent', sc.accent);
document.documentElement.style.setProperty('--season-accent2', sc.accent2);
const CURRENCIES={normal:'Peas',halloween:'Candy Peas',christmas:'Frost Peas',easter:'Egg Peas',thanksgiving:'Maple Peas',spring:'Blossom Peas',summer:'Tropical Peas',birthday:'Cake Peas'};
const storageKey=()=>'antypvz2.peashooterClicker.v2.'+HOLIDAY;
let KEY=storageKey();
const currencyName=()=>CURRENCIES[HOLIDAY]||'Peas';

const seasonThemes = {
  normal: {names:['Lawn Pulse','Green Boost2','Green Cannon2','Green Spin','Pea Cannon','Green Wave','Garden Flood','Garden Rain','Pea Boost','Vine Barrel','Garden Pulse2','Pea Bank','Garden Nova','Pea Power','Garden Storm','Garden Power','Green Rush','Pea Peak','Garden Bank','Green Cluster','Pea Tide','Green Wave2','Pea Flare','Green Sweep','Green Nova','Pea Barrel','Green Boost','Garden Battery','Pea Burst','Vine Helper','Garden Bank2','Vine Net','Lawn Tide','Green Flare','Green Fire','Garden Cannon','Garden Net','Lawn Cannon','Pea Speed','Pea Doubler','Green Barrel','Vine Surge','Lawn Sweep','Lawn Battery','Pea Wave2','Lawn Nova','Pea Armor2','Green Battery','Vine Doubler','Lawn Burst2','Lawn Cluster','Garden Armor2','Green Storm2','Garden Burst','Green Pulse2','Garden Helper','Lawn Spin','Garden Speed','Pea Cluster','Garden Tide','Pea Pulse2','Garden Wave','Green Shield','Pea Cannon2','Vine Battery','Pea Shield2','Pea Battery','Vine Rate','Lawn Fire','Green Shield2','Lawn Pulse2','Pea Burst2','Lawn Storm2','Lawn Wave2','Lawn Helper','Garden Rush','Vine Cannon','Green Pulse','Green Rain','Lawn Flood','Lawn Crush','Pea Rain','Garden Shield2','Green Armor2','Lawn Surge','Vine Shield','Pea Net','Green Net','Vine Burst','Pea Storm2','Pea Spin','Garden Wave2','Lawn Bank','Green Rate','Lawn Rush','Pea Helper','Garden Surge','Green Bank2','Lawn Wave','Garden Cluster','Lawn Cannon2','Vine Boost','Vine Fire','Pea Shield','Pea Fire','Lawn Power','Green Peak','Garden Rate','Pea Rush','Pea Bank2','Green Tide','Vine Pulse','Pea Crush','Lawn Storm','Lawn Rate','Garden Flare','Pea Sweep','Vine Cluster','Lawn Boost','Garden Armor','Garden Sweep','Pea Nova','Garden Pulse','Green Crush','Green Burst2','Pea Rate','Green Surge','Lawn Armor2','Garden Fire','Lawn Doubler','Lawn Barrel','Lawn Speed','Green Speed','Green Helper','Green Avalanche','Lawn Rain','Lawn Bank2','Lawn Shield2','Pea Avalanche','Green Cannon','Green Doubler','Green Bank','Green Burst','Garden Boost2','Garden Doubler','Lawn Boost2','Pea Flood','Pea Boost2','Lawn Flare','Lawn Avalanche','Garden Boost','Lawn Burst','Garden Crush','Lawn Shield','Garden Cannon2','Garden Burst2','Garden Avalanche','Pea Surge','Green Flood','Vine Storm','Green Armor','Lawn Peak','Garden Storm2','Pea Pulse','Garden Spin','Garden Shield','Green Power','Pea Storm','Lawn Net','Pea Wave','Lawn Armor','Green Storm','Garden Barrel','Garden Peak','Pea Armor'], icons:['🌱','🌿','💚','🟢','🌳']},
  halloween: {names:['Witch Barrel','Spook Flood','Ghost Flare','Candy Spin','Bat Surge','Ghost Pulse2','Spook Fire','Ghost Peak','Candy Battery','Witch Burst2','Witch Wave','Bat Shield','Spook Speed','Spook Rate','Candy Surge','Ghost Cannon2','Spook Helper','Candy Cannon2','Witch Boost2','Bat Helper','Candy Speed','Bat Rate','Spook Nova','Ghost Battery','Candy Rain','Ghost Rush','Ghost Bank','Witch Flood','Witch Net','Bat Doubler','Ghost Boost2','Spook Bank2','Spook Wave','Spook Sweep','Candy Boost2','Witch Doubler','Spook Battery','Witch Shield2','Ghost Storm','Ghost Rain','Ghost Helper','Candy Helper','Spook Flare','Ghost Tide','Witch Shield','Candy Net','Ghost Surge','Ghost Storm2','Bat Barrel','Witch Avalanche','Ghost Bank2','Bat Cannon','Ghost Cluster','Witch Cluster','Spook Boost2','Witch Storm','Witch Battery','Ghost Sweep','Spook Storm2','Ghost Wave2','Spook Boost','Spook Avalanche','Witch Nova','Candy Nova','Candy Boost','Ghost Shield','Witch Flare','Witch Crush','Candy Avalanche','Witch Storm2','Spook Cannon','Ghost Cannon','Spook Cluster','Candy Flood','Witch Wave2','Spook Armor','Candy Cannon','Candy Tide','Ghost Armor2','Ghost Fire','Candy Wave','Witch Speed','Candy Rate','Witch Sweep','Witch Rain','Witch Surge','Ghost Crush','Spook Power','Witch Armor','Spook Tide','Candy Armor','Witch Cannon2','Spook Spin','Witch Burst','Spook Surge','Ghost Wave','Ghost Power','Candy Power','Witch Rush','Witch Peak','Spook Pulse2','Ghost Avalanche','Spook Doubler','Ghost Doubler','Ghost Pulse','Candy Shield2','Bat Storm','Bat Burst','Witch Armor2','Spook Shield2','Ghost Barrel','Spook Net','Candy Rush','Witch Spin','Ghost Rate','Candy Pulse2','Ghost Burst','Bat Fire','Ghost Nova','Candy Burst','Candy Sweep','Candy Crush','Candy Storm2','Candy Wave2','Witch Fire','Candy Doubler','Spook Rain','Bat Pulse','Candy Bank','Spook Bank','Witch Helper','Ghost Speed','Ghost Flood','Witch Pulse2','Candy Flare','Candy Storm','Witch Cannon','Spook Cannon2','Candy Bank2','Candy Pulse','Spook Burst2','Bat Net','Witch Pulse','Ghost Boost','Witch Power','Candy Fire','Witch Bank','Spook Wave2','Witch Boost','Ghost Shield2','Candy Barrel','Witch Tide','Candy Armor2','Bat Cluster','Spook Shield','Ghost Spin','Spook Burst','Spook Armor2','Candy Shield','Spook Peak','Candy Burst2','Spook Crush','Spook Rush','Spook Barrel','Bat Boost','Candy Cluster','Witch Bank2','Spook Storm','Ghost Net','Witch Rate','Ghost Burst2','Ghost Armor','Spook Pulse','Candy Peak','Bat Battery'], icons:['🎃','🍬','🦇','👻','🕸️']},
  christmas: {names:['Frost Burst','Frost Cannon2','Holly Bank2','Holly Surge','Ice Boost2','Ice Pulse2','Ice Tide','Frost Shield2','Ice Rain','Frost Peak','Holly Rain','Ice Speed','Frost Rain','Holly Barrel','Ice Flood','Holly Bank','Frost Flare','Frost Surge','Holly Battery','Sleigh Pulse','Ice Cannon2','Sleigh Burst','Holly Cannon','Snow Pulse','Holly Rush','Frost Rush','Frost Bank','Ice Cluster','Holly Helper','Ice Boost','Holly Cannon2','Snow Rate','Frost Power','Ice Storm','Holly Burst','Frost Rate','Snow Battery','Snow Sweep','Ice Armor2','Holly Shield','Snow Helper','Snow Doubler','Ice Net','Holly Armor','Sleigh Storm','Snow Rain','Snow Spin','Holly Crush','Snow Bank','Frost Boost','Frost Flood','Sleigh Battery','Ice Pulse','Ice Sweep','Ice Cannon','Sleigh Barrel','Ice Battery','Snow Storm','Snow Wave','Holly Avalanche','Holly Boost2','Snow Speed','Sleigh Helper','Frost Battery','Holly Storm','Frost Cluster','Holly Speed','Sleigh Doubler','Holly Pulse2','Snow Burst','Snow Shield2','Snow Barrel','Frost Boost2','Ice Barrel','Holly Wave2','Snow Bank2','Holly Armor2','Ice Nova','Frost Nova','Frost Wave','Holly Cluster','Frost Doubler','Sleigh Boost','Sleigh Net','Frost Barrel','Ice Armor','Snow Burst2','Ice Shield2','Holly Spin','Frost Cannon','Holly Rate','Ice Burst2','Sleigh Fire','Sleigh Shield','Ice Power','Frost Speed','Snow Storm2','Holly Nova','Snow Cannon2','Ice Helper','Holly Flood','Snow Peak','Snow Cannon','Frost Wave2','Snow Surge','Snow Nova','Snow Pulse2','Sleigh Cannon','Sleigh Rate','Snow Rush','Sleigh Surge','Ice Flare','Ice Doubler','Snow Avalanche','Ice Avalanche','Frost Burst2','Ice Bank','Snow Power','Snow Crush','Snow Shield','Holly Fire','Ice Peak','Ice Bank2','Ice Shield','Snow Armor','Frost Avalanche','Ice Fire','Holly Doubler','Holly Power','Holly Tide','Frost Sweep','Holly Pulse','Snow Boost2','Snow Tide','Holly Storm2','Frost Armor','Frost Storm','Ice Crush','Frost Fire','Sleigh Cluster','Ice Storm2','Ice Spin','Ice Rate','Snow Boost','Ice Burst','Holly Peak','Frost Pulse','Frost Pulse2','Frost Armor2','Holly Boost','Ice Rush','Frost Storm2','Frost Bank2','Holly Flare','Snow Flood','Frost Net','Holly Net','Snow Wave2','Ice Wave','Snow Cluster','Frost Shield','Frost Spin','Holly Shield2','Snow Fire','Frost Tide','Holly Wave','Holly Sweep','Ice Wave2','Holly Burst2','Snow Net','Snow Armor2','Frost Crush','Snow Flare','Frost Helper','Ice Surge'], icons:['❄️','🎄','✨','🎁','⛄']},
  easter: {names:['Bloom Boost2','Bunny Cannon','Bunny Wave2','Hop Storm','Spring Speed','Bunny Power','Bunny Net','Spring Cluster','Bloom Burst2','Bunny Rain','Egg Wave','Egg Barrel','Bloom Speed','Egg Burst','Bunny Wave','Spring Boost','Spring Bank','Bunny Helper','Spring Barrel','Bloom Spin','Hop Helper','Bloom Peak','Egg Armor2','Bunny Sweep','Egg Pulse','Bloom Boost','Hop Barrel','Bunny Crush','Egg Flare','Spring Burst2','Bloom Net','Egg Boost','Bloom Flood','Spring Flare','Egg Power','Spring Shield2','Bloom Armor2','Bunny Shield2','Spring Rush','Bloom Pulse','Bunny Boost2','Hop Fire','Bunny Pulse2','Spring Sweep','Bunny Speed','Spring Pulse','Bunny Battery','Egg Storm2','Egg Bank2','Bunny Tide','Spring Crush','Bloom Battery','Bunny Armor2','Egg Fire','Bunny Rate','Hop Burst','Spring Nova','Hop Boost','Bloom Armor','Spring Burst','Bloom Rate','Egg Nova','Bunny Flood','Bunny Flare','Spring Bank2','Bloom Barrel','Bloom Rain','Bunny Barrel','Egg Crush','Egg Cannon2','Bunny Peak','Hop Cannon','Bunny Armor','Spring Cannon2','Spring Flood','Spring Helper','Spring Rain','Egg Rush','Bunny Bank2','Spring Fire','Egg Helper','Hop Pulse','Egg Pulse2','Bloom Surge','Spring Storm2','Bloom Cannon','Bloom Bank','Bunny Shield','Bunny Avalanche','Spring Wave2','Bloom Burst','Bunny Burst2','Egg Tide','Hop Rate','Bunny Fire','Egg Storm','Bunny Nova','Bunny Bank','Bunny Storm2','Hop Cluster','Egg Rate','Spring Surge','Bunny Rush','Spring Avalanche','Egg Cannon','Bunny Surge','Bloom Power','Egg Rain','Bunny Cannon2','Spring Tide','Spring Boost2','Egg Wave2','Spring Armor','Hop Battery','Spring Battery','Spring Cannon','Bloom Wave2','Egg Spin','Egg Shield2','Bunny Pulse','Bloom Storm2','Egg Bank','Bunny Doubler','Bloom Rush','Hop Shield','Bloom Sweep','Bloom Shield','Egg Shield','Bloom Pulse2','Bloom Avalanche','Spring Spin','Bloom Cannon2','Egg Battery','Spring Wave','Bloom Helper','Bloom Cluster','Bloom Storm','Bloom Fire','Spring Doubler','Spring Net','Spring Rate','Bunny Cluster','Bloom Wave','Bloom Shield2','Bunny Spin','Egg Burst2','Bloom Nova','Bloom Crush','Bloom Tide','Egg Doubler','Egg Surge','Bunny Storm','Bloom Bank2','Hop Net','Hop Surge','Bunny Burst','Bloom Flare','Egg Boost2','Bloom Doubler','Spring Pulse2','Egg Sweep','Egg Cluster','Egg Net','Egg Speed','Spring Peak','Egg Avalanche','Spring Shield','Spring Armor2','Egg Armor','Spring Power','Hop Doubler','Egg Peak','Spring Storm','Bunny Boost','Egg Flood'], icons:['🐰','🥚','🌸','🐣','🌷']},
  thanksgiving: {names:['Harvest Storm2','Corn Cannon2','Gravy Nova','Feast Storm2','Harvest Boost','Gravy Rate','Corn Avalanche','Feast Sweep','Feast Helper','Corn Power','Gravy Power','Feast Burst2','Harvest Cluster','Feast Rush','Corn Cannon','Corn Bank','Corn Doubler','Feast Tide','Harvest Nova','Harvest Burst2','Harvest Rate','Gravy Pulse2','Gobble Cannon','Harvest Wave','Feast Wave','Harvest Bank','Harvest Pulse','Gobble Pulse','Feast Net','Corn Fire','Gravy Tide','Gobble Storm','Harvest Flood','Corn Battery','Corn Flare','Corn Cluster','Corn Wave2','Harvest Crush','Feast Wave2','Feast Armor2','Corn Rush','Harvest Flare','Corn Sweep','Harvest Armor','Gravy Flare','Feast Flare','Gravy Spin','Corn Burst2','Gravy Pulse','Gobble Surge','Harvest Barrel','Gravy Cluster','Feast Cannon2','Feast Storm','Gravy Fire','Feast Doubler','Gobble Burst','Corn Flood','Corn Nova','Corn Armor','Harvest Wave2','Feast Cluster','Feast Spin','Gravy Net','Corn Bank2','Feast Bank2','Gobble Shield','Gravy Burst2','Gobble Rate','Gravy Wave2','Feast Avalanche','Harvest Cannon2','Feast Shield2','Corn Barrel','Gravy Surge','Harvest Avalanche','Harvest Helper','Harvest Tide','Corn Shield2','Corn Rate','Feast Rate','Gravy Storm','Harvest Pulse2','Corn Surge','Corn Pulse2','Gravy Storm2','Feast Crush','Gravy Rush','Feast Surge','Gravy Burst','Gravy Armor','Corn Helper','Harvest Surge','Feast Shield','Gravy Crush','Feast Nova','Corn Spin','Feast Rain','Feast Speed','Gravy Wave','Feast Power','Gravy Doubler','Corn Armor2','Gravy Boost','Gobble Battery','Corn Pulse','Harvest Boost2','Harvest Armor2','Feast Fire','Corn Storm','Gravy Speed','Feast Peak','Feast Burst','Gravy Avalanche','Gravy Battery','Harvest Rain','Feast Boost','Feast Bank','Feast Cannon','Feast Flood','Harvest Shield','Corn Net','Corn Boost','Gravy Bank','Feast Battery','Harvest Shield2','Gobble Fire','Harvest Peak','Harvest Power','Gravy Shield2','Gravy Armor2','Harvest Net','Gravy Flood','Gravy Cannon','Feast Barrel','Harvest Burst','Gravy Shield','Gravy Barrel','Gobble Cluster','Harvest Doubler','Gobble Net','Corn Tide','Harvest Cannon','Gobble Doubler','Feast Pulse','Harvest Bank2','Feast Pulse2','Corn Crush','Corn Boost2','Harvest Rush','Feast Armor','Corn Speed','Gravy Sweep','Harvest Storm','Gobble Helper','Gravy Cannon2','Gravy Peak','Corn Peak','Harvest Speed','Harvest Sweep','Gobble Barrel','Gravy Helper','Gobble Boost','Corn Wave','Harvest Battery','Gravy Boost2','Gravy Rain','Corn Shield','Harvest Fire','Corn Burst','Gravy Bank2','Harvest Spin','Corn Storm2','Feast Boost2','Corn Rain'], icons:['🍁','🦃','🌽','🍂','🥧']},
  spring: {names:['Blossom Speed','Blossom Power','Tulip Peak','Tulip Rush','Blossom Sweep','Tulip Surge','Tulip Flood','Tulip Shield2','Tulip Storm','Tulip Helper','Flutter Doubler','Blossom Shield','Blossom Barrel','Tulip Shield','Blossom Armor2','Petal Peak','Tulip Pulse','Petal Shield','Tulip Burst2','Bee Helper','Tulip Cluster','Tulip Net','Bee Speed','Bee Doubler','Petal Burst','Blossom Fire','Tulip Bank','Petal Storm2','Blossom Cannon','Blossom Net','Bee Burst2','Blossom Cluster','Bee Boost','Bee Storm','Tulip Wave2','Bee Flood','Bee Cannon','Flutter Cannon','Bee Surge','Blossom Helper','Tulip Tide','Blossom Nova','Petal Burst2','Flutter Storm','Bee Pulse','Blossom Tide','Flutter Helper','Tulip Fire','Bee Wave','Bee Power','Bee Nova','Blossom Storm','Petal Rain','Bee Cluster','Tulip Storm2','Petal Boost2','Tulip Crush','Bee Fire','Tulip Cannon','Petal Cluster','Bee Pulse2','Petal Cannon2','Blossom Burst','Petal Wave','Petal Surge','Tulip Cannon2','Blossom Armor','Tulip Battery','Petal Doubler','Flutter Cluster','Tulip Power','Flutter Shield','Blossom Bank2','Blossom Rain','Petal Helper','Petal Battery','Tulip Pulse2','Petal Bank2','Blossom Wave','Tulip Barrel','Blossom Surge','Blossom Spin','Blossom Boost2','Bee Rate','Bee Armor','Petal Bank','Flutter Battery','Tulip Nova','Bee Burst','Tulip Sweep','Blossom Peak','Petal Armor','Blossom Crush','Flutter Fire','Petal Armor2','Tulip Armor','Blossom Pulse2','Petal Storm','Bee Bank2','Petal Net','Petal Fire','Petal Avalanche','Petal Rate','Blossom Shield2','Bee Crush','Petal Speed','Blossom Storm2','Bee Boost2','Petal Tide','Bee Wave2','Flutter Rate','Blossom Flood','Blossom Avalanche','Petal Rush','Petal Shield2','Bee Peak','Bee Cannon2','Flutter Barrel','Tulip Wave','Bee Flare','Bee Net','Blossom Flare','Tulip Boost2','Blossom Pulse','Petal Flood','Tulip Avalanche','Flutter Surge','Tulip Boost','Blossom Rush','Petal Power','Petal Barrel','Bee Avalanche','Bee Storm2','Tulip Spin','Bee Rain','Petal Crush','Petal Flare','Bee Bank','Bee Sweep','Bee Spin','Blossom Boost','Petal Spin','Tulip Armor2','Flutter Boost','Blossom Wave2','Tulip Burst','Blossom Doubler','Petal Boost','Blossom Cannon2','Tulip Bank2','Petal Nova','Bee Barrel','Petal Pulse','Tulip Rate','Tulip Speed','Blossom Battery','Blossom Burst2','Tulip Rain','Bee Tide','Petal Cannon','Tulip Doubler','Bee Armor2','Flutter Burst','Flutter Net','Bee Shield2','Petal Pulse2','Petal Wave2','Flutter Pulse','Bee Shield','Blossom Rate','Tulip Flare','Blossom Bank','Bee Battery','Petal Sweep','Bee Rush'], icons:['🌸','🌷','🦋','🌼','🐝']},
  birthday: {names:['Cake Rain','Frosting Rush','Party Pulse2','Frosting Battery','Balloon Rush','Cake Flood','Confetti Cluster','Confetti Boost','Balloon Avalanche','Cake Shield','Party Nova','Cake Boost2','Party Power','Balloon Burst','Cake Surge','Cake Armor2','Cake Cluster','Frosting Nova','Party Surge','Frosting Boost2','Party Peak','Cake Tide','Balloon Flood','Frosting Burst2','Balloon Power','Balloon Shield','Party Battery','Balloon Battery','Frosting Bank2','Frosting Cannon','Balloon Surge','Confetti Burst','Party Burst','Frosting Helper','Cake Spin','Balloon Storm','Cake Storm','Confetti Doubler','Balloon Wave','Party Spin','Party Boost2','Frosting Peak','Party Bank','Balloon Armor','Party Bank2','Party Flare','Balloon Crush','Cake Doubler','Party Tide','Balloon Bank','Balloon Peak','Frosting Wave','Party Armor2','Cake Crush','Confetti Helper','Party Cannon','Frosting Power','Cake Pulse','Cake Flare','Balloon Sweep','Cake Boost','Balloon Rain','Cake Helper','Frosting Barrel','Balloon Spin','Balloon Rate','Party Wave2','Balloon Pulse','Frosting Shield2','Party Flood','Party Net','Frosting Fire','Balloon Barrel','Cake Burst','Cake Net','Party Storm2','Frosting Flare','Party Boost','Balloon Boost2','Balloon Shield2','Confetti Pulse','Frosting Flood','Confetti Net','Balloon Net','Cake Fire','Balloon Cannon','Frosting Spin','Cake Battery','Cake Peak','Cake Rate','Frosting Net','Confetti Battery','Party Armor','Party Rate','Frosting Boost','Cake Rush','Balloon Flare','Frosting Sweep','Party Barrel','Balloon Nova','Party Doubler','Frosting Pulse','Balloon Cannon2','Frosting Crush','Party Sweep','Party Fire','Balloon Fire','Balloon Wave2','Cake Wave','Balloon Pulse2','Confetti Rate','Party Shield','Frosting Speed','Party Shield2','Balloon Burst2','Party Speed','Balloon Armor2','Party Avalanche','Frosting Tide','Cake Armor','Party Cannon2','Party Burst2','Cake Bank2','Frosting Armor2','Confetti Barrel','Party Rain','Cake Storm2','Frosting Cannon2','Cake Power','Balloon Bank2','Party Pulse','Cake Cannon','Cake Shield2','Balloon Storm2','Frosting Storm','Confetti Storm','Balloon Cluster','Cake Sweep','Cake Barrel','Cake Bank','Frosting Shield','Party Rush','Frosting Pulse2','Cake Wave2','Confetti Surge','Frosting Storm2','Cake Avalanche','Party Cluster','Frosting Avalanche','Frosting Cluster','Party Helper','Cake Speed','Frosting Surge','Balloon Tide','Frosting Rain','Confetti Shield','Cake Cannon2','Cake Pulse2','Frosting Doubler','Frosting Bank','Frosting Wave2','Frosting Armor','Balloon Doubler','Confetti Fire','Party Storm','Balloon Boost','Cake Burst2','Party Wave','Balloon Helper','Frosting Rate','Balloon Speed','Party Crush','Frosting Burst','Confetti Cannon','Cake Nova'], icons:['🎂','🎈','🎉','🎁','🥳']},
  summer: {names:['Tropical Pulse','Melon Pulse2','Tropical Surge','Tropical Crush','Tropical Cannon2','Tropical Doubler','Melon Tide','Wave Wave2','Wave Bank2','Wave Cluster','Wave Net','Tropical Spin','Tropical Burst2','Sun Rush','Wave Armor','Sun Wave2','Melon Spin','Melon Battery','Wave Battery','Tropical Avalanche','Sun Barrel','Melon Wave','Sun Flare','Melon Flood','Surf Net','Sun Wave','Wave Fire','Melon Net','Melon Barrel','Wave Storm','Sun Cluster','Melon Burst','Sun Armor2','Sun Burst','Tropical Rain','Sun Rain','Melon Bank','Sun Cannon2','Wave Spin','Melon Speed','Tropical Boost','Sun Tide','Wave Armor2','Sun Crush','Wave Shield2','Melon Flare','Sun Shield2','Surf Pulse','Tropical Bank','Sun Power','Tropical Fire','Tropical Speed','Melon Rush','Wave Shield','Sun Storm2','Melon Cluster','Tropical Flood','Surf Battery','Tropical Shield','Wave Flood','Melon Cannon','Wave Rate','Wave Speed','Tropical Pulse2','Sun Avalanche','Wave Boost','Surf Cannon','Wave Cannon','Sun Surge','Melon Pulse','Wave Rain','Surf Doubler','Sun Helper','Sun Fire','Wave Rush','Sun Rate','Tropical Nova','Melon Peak','Surf Boost','Sun Doubler','Wave Peak','Tropical Armor','Sun Flood','Sun Sweep','Sun Bank','Sun Burst2','Melon Avalanche','Surf Surge','Surf Storm','Melon Doubler','Tropical Rate','Wave Barrel','Surf Fire','Tropical Cannon','Wave Crush','Tropical Boost2','Sun Peak','Sun Storm','Tropical Tide','Wave Doubler','Melon Storm','Sun Net','Melon Bank2','Melon Shield','Melon Sweep','Wave Tide','Wave Burst','Melon Helper','Wave Surge','Wave Storm2','Tropical Armor2','Melon Armor','Tropical Helper','Surf Barrel','Tropical Battery','Tropical Peak','Wave Wave','Sun Pulse2','Wave Burst2','Wave Pulse','Melon Boost2','Wave Flare','Sun Speed','Sun Pulse','Tropical Barrel','Tropical Rush','Tropical Flare','Tropical Cluster','Sun Cannon','Melon Crush','Sun Battery','Sun Boost2','Wave Bank','Melon Wave2','Tropical Net','Wave Power','Wave Cannon2','Tropical Storm2','Surf Shield','Tropical Shield2','Wave Avalanche','Sun Bank2','Tropical Power','Surf Burst','Sun Nova','Tropical Wave2','Tropical Storm','Surf Helper','Melon Surge','Melon Fire','Tropical Bank2','Melon Burst2','Melon Rate','Wave Pulse2','Melon Storm2','Sun Shield','Melon Cannon2','Surf Rate','Wave Nova','Wave Sweep','Wave Boost2','Melon Armor2','Surf Cluster','Sun Spin','Melon Power','Sun Boost','Melon Shield2','Sun Armor','Tropical Burst','Melon Nova','Melon Boost','Tropical Sweep','Melon Rain','Tropical Wave','Wave Helper'], icons:['🌺','🏖️','☀️','🌴','🍉']}
};
function makeSeasonUpgrades(season){
  const t = seasonThemes[season] || seasonThemes.normal;
  const list = [];
  for(let i=1;i<=250;i++){
    const isClick = i % 2 === 1;
    const tier = Math.ceil(i/8);
    const base = Math.round(40 * Math.pow(1.48, i-1));
    list.push({
      id: season + '_u' + i,
      name: t.names[(i-1) % t.names.length],
      desc: (isClick ? '+'+(2+tier) + ' per tap' : '+'+(1+tier) + ' per second') + ' · ' + t.names[(i-1) % t.names.length],
      base: base,
      growth: 1.48 + (tier*0.03),
      kind: isClick ? 'click' : 'passive',
      amount: isClick ? 2+tier : 1+tier,
      icon: t.icons[(i-1) % t.icons.length]
    });
  }
  return list;
}
const coreUpgrades = [
 {id:'double',name:'Double Peashooter',desc:'A second barrel adds +1 pea per tap.',base:25,growth:1.55,kind:'click',amount:1,icon:'🌱'},
 {id:'sunflower',name:'Sunflower',desc:'A classic helper: generates peas every second.',base:50,growth:1.6,kind:'passive',amount:1,icon:'🌻'}
];
let upgrades = coreUpgrades.concat(makeSeasonUpgrades(HOLIDAY));

const achievementDefs=[
 {id:'peas100',name:'Pea Picker',desc:'Earn 100 total peas',check:s=>s.totalEarned>=100},
 {id:'peas1000',name:'Pea Enthusiast',desc:'Earn 1,000 total peas',check:s=>s.totalEarned>=1000},
 {id:'peas10000',name:'Pea Tycoon',desc:'Earn 10,000 total peas',check:s=>s.totalEarned>=10000},
 {id:'peas100000',name:'Pea Millionaire',desc:'Earn 100,000 total peas',check:s=>s.totalEarned>=100000},
 {id:'peas1000000',name:'Pea Legend',desc:'Earn 1,000,000 total peas',check:s=>s.totalEarned>=1000000},
 {id:'garden',name:'Green Thumb',desc:'Own 10 total upgrades',check:s=>upgrades.reduce((n,u)=>n+s.owned[u.id],0)>=10},
 {id:'collector',name:'Full Greenhouse',desc:'Own every upgrade type',check:s=>upgrades.every(u=>s.owned[u.id]>0)},
 {id:'zombies10',name:'Lawn Defender',desc:'Defeat 10 zombies',check:s=>s.zombiesDefeated>=10},
 {id:'zombies25',name:'Zombie Bouncer',desc:'Defeat 25 zombies',check:s=>s.zombiesDefeated>=25},
 {id:'zombies50',name:'Lawn Legend',desc:'Defeat 50 zombies',check:s=>s.zombiesDefeated>=50},
 {id:'wave10',name:'Wave Breaker',desc:'Reach wave 10',check:s=>s.zombieStage>=10},
 {id:'clicks500',name:'Tap Machine',desc:'Collect peas from 500 clicks',check:s=>s.clicks>=500},
 {id:'peas5m',name:'Pea Empire',desc:'Earn 5,000,000 total peas',check:s=>s.totalEarned>=5000000},
 {id:'peas50m',name:'Pea Dynasty',desc:'Earn 50,000,000 total peas',check:s=>s.totalEarned>=50000000},
 {id:'peas500m',name:'Pea Universe',desc:'Earn 500,000,000 total peas',check:s=>s.totalEarned>=500000000},
 {id:'clicks1k',name:'Click Veteran',desc:'Click 1,000 times',check:s=>s.clicks>=1000},
 {id:'clicks5k',name:'Click Master',desc:'Click 5,000 times',check:s=>s.clicks>=5000},
 {id:'clicks10k',name:'Click Legend',desc:'Click 10,000 times',check:s=>s.clicks>=10000},
 {id:'zombies100',name:'Zombie Slayer',desc:'Defeat 100 zombies',check:s=>s.zombiesDefeated>=100},
 {id:'zombies250',name:'Horde Breaker',desc:'Defeat 250 zombies',check:s=>s.zombiesDefeated>=250},
 {id:'zombies500',name:'Apocalypse Survivor',desc:'Defeat 500 zombies',check:s=>s.zombiesDefeated>=500},
 {id:'wave25',name:'Wave Rider',desc:'Reach wave 25',check:s=>s.zombieStage>=25},
 {id:'wave50',name:'Wave Master',desc:'Reach wave 50',check:s=>s.zombieStage>=50},
 {id:'wave100',name:'Wave God',desc:'Reach wave 100',check:s=>s.zombieStage>=100},
 {id:'rebirth1',name:'First Rebirth',desc:'Rebirth once',check:s=>s.rebirths>=1},
 {id:'rebirth5',name:'Reborn',desc:'Rebirth 5 times',check:s=>s.rebirths>=5},
 {id:'rebirth10',name:'Cycle Master',desc:'Rebirth 10 times',check:s=>s.rebirths>=10},
 {id:'prestige1',name:'First Prestige',desc:'Prestige once',check:s=>s.prestiges>=1},
 {id:'prestige5',name:'Prestigious',desc:'Prestige 5 times',check:s=>s.prestiges>=5},
 {id:'prestige10',name:'Prestige Lord',desc:'Prestige 10 times',check:s=>s.prestiges>=10},
 {id:'ascension1',name:'First Ascension',desc:'Ascend once',check:s=>s.ascensions>=1},
 {id:'ascension3',name:'Transcendent',desc:'Ascend 3 times',check:s=>s.ascensions>=3},
 {id:'ascension5',name:'Ascended',desc:'Ascend 5 times',check:s=>s.ascensions>=5},
 {id:'gold10',name:'Gold Finder',desc:'Hold 10 gold bars',check:s=>s.goldBars>=10},
 {id:'gold50',name:'Gold Hoarder',desc:'Hold 50 gold bars',check:s=>s.goldBars>=50},
 {id:'gold100',name:'Gold Baron',desc:'Hold 100 gold bars',check:s=>s.goldBars>=100},
 {id:'upgrades25',name:'Upgrade Collector',desc:'Own 25 total upgrades',check:s=>upgrades.reduce((n,u)=>n+(s.owned[u.id]||0),0)>=25},
 {id:'upgrades50',name:'Upgrade Hoarder',desc:'Own 50 total upgrades',check:s=>upgrades.reduce((n,u)=>n+(s.owned[u.id]||0),0)>=50},
 {id:'upgrades100',name:'Upgrade King',desc:'Own 100 total upgrades',check:s=>upgrades.reduce((n,u)=>n+(s.owned[u.id]||0),0)>=100},
 {id:'skills10',name:'Skill Learner',desc:'Unlock 10 skills',check:s=>Object.keys(s.skills||{}).length>=10},
 {id:'skills50',name:'Skill Adept',desc:'Unlock 50 skills',check:s=>Object.keys(s.skills||{}).length>=50},
 {id:'skills100',name:'Skill Master',desc:'Unlock 100 skills',check:s=>Object.keys(s.skills||{}).length>=100},
 {id:'crit100',name:'Lucky Shot',desc:'Land 100 critical hits',check:s=>(s.crits||0)>=100},
 {id:'bonus10',name:'Bonus Hunter',desc:'Collect 10 bonuses',check:s=>(s.bonuses||0)>=10},
 {id:'bonus50',name:'Bonus Addict',desc:'Collect 50 bonuses',check:s=>(s.bonuses||0)>=50},
 {id:'play1h',name:'Dedicated',desc:'Play for 1 hour total',check:s=>(s.playTime||0)>=3600},
 {id:'rate100',name:'Passive Income',desc:'Reach 100 peas per second',check:s=>peaRate()>=100},
 {id:'power100',name:'Heavy Hitter',desc:'Reach 100 click power',check:s=>clickPower()>=100},
 {id:'power1k',name:'Devastator',desc:'Reach 1,000 click power',check:s=>clickPower()>=1000}
];
const $=id=>{const el=document.getElementById(id);return el||{textContent:'',style:{},classList:{add(){},remove(){},toggle(){}},setAttribute(){},addEventListener(){},append(){},appendChild(){},getBoundingClientRect(){return{left:0,top:0,width:0,height:0}},disabled:false,innerHTML:'',value:''};};var state=null;var lastTick=Date.now();var audioReady=false;window.state=state;
function fresh(){return {peas:0,rebirths:0,prestiges:0,ascensions:0,totalEarned:0,zombiesDefeated:0,owned:Object.assign({double:0,sunflower:0,repeater:0,threepeater:0,gatling:0,megagatling:0},Object.fromEntries(upgrades.map(u=>[u.id,0]))),clicks:0,selectedPlant:'pea',zombieStage:1,zombieHp:20,zombieMaxHp:20,wave:null,waveIndex:0,spawnDelay:0,unlocked:[],muted:false,volume:35,goldBars:0,plantLevels:{pea:0,repeater:0,threepeater:0,mega:0,shadow:0,greenshadow:0,electric:0,fire:0,snow:0,goo:0},fertilizer:{pea:0,repeater:0,threepeater:0,mega:0,shadow:0,greenshadow:0,electric:0,fire:0,snow:0,goo:0},skills:{}};}
function load(){try{const raw=JSON.parse(localStorage.getItem(KEY)||'null');if(!raw||typeof raw!=='object')return fresh();const s=fresh();s.peas=finite(raw.peas);s.rebirths=Math.max(0,Math.floor(finite(raw.rebirths)));s.prestiges=Math.max(0,Math.floor(finite(raw.prestiges)));s.ascensions=Math.max(0,Math.floor(finite(raw.ascensions)));s.totalEarned=finite(raw.totalEarned);s.zombiesDefeated=finite(raw.zombiesDefeated);s.clicks=finite(raw.clicks);s.selectedPlant=['pea','repeater','threepeater','mega','shadow','greenshadow','electric','fire','snow','goo'].includes(raw.selectedPlant)?raw.selectedPlant:'pea';s.zombieStage=Math.max(1,Math.floor(finite(raw.zombieStage)||1));s.zombieMaxHp=Math.max(20,finite(raw.zombieMaxHp)||20);s.zombieHp=Math.min(s.zombieMaxHp,Math.max(0,finite(raw.zombieHp)||s.zombieMaxHp));s.wave=Array.isArray(raw.wave)?raw.wave:null;s.waveIndex=Math.max(0,Math.floor(finite(raw.waveIndex)||0));upgrades.forEach(u=>s.owned[u.id]=Math.max(0,Math.floor(finite(raw.owned&&raw.owned[u.id]))));s.unlocked=Array.isArray(raw.unlocked)?raw.unlocked.filter(id=>achievementDefs.some(a=>a.id===id)):[];s.muted=!!raw.muted;s.volume=Math.max(0,Math.min(100,finite(raw.volume)||35));s.goldBars=Math.floor(finite(raw.goldBars));s.skills=(raw.skills&&typeof raw.skills==='object')?raw.skills:{};['pea','repeater','threepeater','mega','shadow','greenshadow','electric','fire','snow','goo'].forEach(k=>{s.plantLevels[k]=Math.floor(finite(raw.plantLevels&&raw.plantLevels[k]));s.fertilizer[k]=Math.floor(finite(raw.fertilizer&&raw.fertilizer[k]));});return s;}catch(e){return fresh();}}
function finite(v){const n=Number(v);return Number.isFinite(n)&&n>0?n:0;}
function save(){try{localStorage.setItem(KEY,JSON.stringify(state));}catch(e){$('clicker-hint').textContent='Browser storage is unavailable. Progress may not persist after closing this page.';}}
const LB_LOCAL_KEY='antypvz2.peashooterClicker.leaderboards.v2';
const LB_CATEGORIES=[['peas','Highest Peas',s=>Math.max(s.peas||0,s.totalEarned||0)],['gold_bars','Highest Gold Bars',s=>s.goldBars||0],['rebirths','Highest Rebirth',s=>s.rebirths||0],['prestiges','Highest Prestige',s=>s.prestiges||0],['ascensions','Highest Ascension',s=>s.ascensions||0]];
let lbClient=null,lbUser=null,lbBusy=false,lbLastPush=0,lbPushTimer=null;
function lbLocal(){try{return JSON.parse(localStorage.getItem(LB_LOCAL_KEY)||'{}')||{};}catch(e){return {};}}
function lbLocalSave(v){try{localStorage.setItem(LB_LOCAL_KEY,JSON.stringify(v));}catch(e){}}
function lbNote(message){const el=$('leaderboard-note');if(el)el.textContent=message;}
function lbConfigured(){const c=window.ANTYPVZ2_SUPABASE||{};return !!(window.supabase&&window.supabase.createClient&&c.url&&c.anonKey&&!c.url.includes('YOUR-PROJECT')&&!c.anonKey.includes('YOUR-PUBLISHABLE'));}
function lbEscapeName(v){return String(v||'').trim().replace(/[<>]/g,'').slice(0,20)||'Player';}
function lbLocalBest(){const d=lbLocal();const uid=lbUser?lbUser.id:'guest';if(!d[uid])d[uid]={username:'',peas:0,gold_bars:0,rebirths:0,prestiges:0,ascensions:0};const row=d[uid];LB_CATEGORIES.forEach(([key,label,fn])=>row[key]=Math.max(Number(row[key])||0,Number(fn(state))||0));lbLocalSave(d);return row;}
function lbRenderLists(data){LB_CATEGORIES.forEach(([key,label])=>{const list=$('leaderboard-'+({'gold_bars':'gold','rebirths':'rebirth','prestiges':'prestige','ascensions':'ascension','peas':'peas'}[key]));if(!list)return;list.replaceChildren();const rows=(data||[]).map(r=>({name:r.username||'Player',value:Math.max(0,Number(r[key])||0)}));if(!rows.length){const li=document.createElement('li');li.className='leaderboard-empty';li.textContent='No scores yet';list.append(li);return;}rows.forEach((entry,i)=>{const li=document.createElement('li');li.className='leaderboard-row';const n=document.createElement('span');n.textContent=(i+1)+'. '+entry.name;const v=document.createElement('strong');v.textContent=fmt(entry.value);li.append(n,v);list.append(li);});});}
function lbRenderLocal(){const row=lbLocalBest();lbRenderLists([{username:row.username||'Your local score',...row}]);}
async function lbFetchBoards(){if(!lbClient){lbRenderLocal();return;}try{const results=await Promise.all(LB_CATEGORIES.map(([key])=>lbClient.from('clicker_scores').select('username,'+key).order(key,{ascending:false}).limit(10)));const error=results.find(r=>r.error);if(error)throw error.error;LB_CATEGORIES.forEach(([key])=>{const list=$('leaderboard-'+({'gold_bars':'gold','rebirths':'rebirth','prestiges':'prestige','ascensions':'ascension','peas':'peas'}[key]));if(!list)return;list.replaceChildren();const rows=results[LB_CATEGORIES.findIndex(c=>c[0]===key)].data||[];if(!rows.length){const li=document.createElement('li');li.className='leaderboard-empty';li.textContent='No scores yet';list.append(li);return;}rows.forEach((entry,i)=>{const li=document.createElement('li');li.className='leaderboard-row';const n=document.createElement('span');n.textContent=(i+1)+'. '+(entry.username||'Player');const v=document.createElement('strong');v.textContent=fmt(Number(entry[key])||0);li.append(n,v);list.append(li);});});}catch(e){lbNote('Could not load shared scores. Check the Supabase URL/key, SQL setup, and internet connection. '+(e.message||''));}}
async function lbPushScores(force=false){if(!lbClient||!lbUser||lbBusy)return;if(!force&&Date.now()-lbLastPush<12000)return;lbBusy=true;try{const local=lbLocalBest();const {data:existing,error:readError}=await lbClient.from('clicker_scores').select('*').eq('user_id',lbUser.id).maybeSingle();if(readError)throw readError;const row={user_id:lbUser.id,username:lbEscapeName($('leaderboard-player').value||local.username||lbUser.email?.split('@')[0]),peas:Math.max(Number(local.peas)||0,Number(existing?.peas)||0),gold_bars:Math.max(Number(local.gold_bars)||0,Number(existing?.gold_bars)||0),rebirths:Math.max(Number(local.rebirths)||0,Number(existing?.rebirths)||0),prestiges:Math.max(Number(local.prestiges)||0,Number(existing?.prestiges)||0),ascensions:Math.max(Number(local.ascensions)||0,Number(existing?.ascensions)||0),updated_at:new Date().toISOString()};const {error}=await lbClient.from('clicker_scores').upsert(row,{onConflict:'user_id'});if(error)throw error;local.username=row.username;lbLocalSave({...lbLocal(),[lbUser.id]:local});lbLastPush=Date.now();lbNote('Signed in as '+row.username+'. Your best scores are synced to the shared leaderboards.');await lbFetchBoards();}catch(e){lbNote('Score sync failed: '+(e.message||'Check your Supabase setup.'));}finally{lbBusy=false;}}
function lbSchedulePush(){if(!lbUser||!lbClient||lbPushTimer)return;lbPushTimer=setTimeout(()=>{lbPushTimer=null;lbPushScores(false);},2500);}
function lbUpdateAuthUI(){const signed=!!lbUser;$('leaderboard-signup').hidden=signed;$('leaderboard-login').hidden=signed;$('leaderboard-logout').hidden=!signed;$('leaderboard-email').disabled=signed;$('leaderboard-password').disabled=signed;$('leaderboard-player').disabled=signed&&false;if(lbUser){const d=lbLocal();const row=d[lbUser.id]||{};$('leaderboard-player').value=row.username||lbUser.user_metadata?.username||lbUser.email?.split('@')[0]||'Player';}}
async function lbInit(){if(!lbConfigured()){lbRenderLocal();lbNote('Setup needed: create a Supabase project, add its URL and publishable key to supabase-config.js, and run SUPABASE-LEADERBOARDS.sql. Local score tracking continues until configured.');return;}const cfg=window.ANTYPVZ2_SUPABASE;lbClient=window.supabase.createClient(cfg.url,cfg.anonKey);const {data,error}=await lbClient.auth.getSession();if(error)lbNote('Auth status error: '+error.message);lbUser=data?.session?.user||null;lbUpdateAuthUI();await lbFetchBoards();if(lbUser)await lbPushScores(true);lbClient.auth.onAuthStateChange((event,session)=>{lbUser=session?.user||null;lbUpdateAuthUI();setTimeout(async()=>{if(lbUser){await lbPushScores(true);}else{lbNote('Signed out. You can still view shared rankings; sign in to submit scores.');await lbFetchBoards();}},0);});}
$('leaderboard-signup')?.addEventListener('click',async()=>{if(!lbConfigured()){lbNote('Configure Supabase first using supabase-config.js and SUPABASE-LEADERBOARDS.sql.');return;}const email=$('leaderboard-email').value.trim(),password=$('leaderboard-password').value,username=lbEscapeName($('leaderboard-player').value);if(!email||password.length<8){lbNote('Enter a valid email and a password of at least 8 characters.');return;}const {data,error}=await lbClient.auth.signUp({email,password,options:{data:{username}}});if(error){lbNote('Could not create account: '+error.message);return;}const d=lbLocal();d[data.user?.id||'pending']={username,peas:0,gold_bars:0,rebirths:0,prestiges:0,ascensions:0};lbLocalSave(d);lbNote(data.session?'Account created and signed in.':'Account created. Check your email to confirm the account, then sign in.');});
$('leaderboard-login')?.addEventListener('click',async()=>{if(!lbConfigured()){lbNote('Configure Supabase first using supabase-config.js and SUPABASE-LEADERBOARDS.sql.');return;}const email=$('leaderboard-email').value.trim(),password=$('leaderboard-password').value;if(!email||!password){lbNote('Enter your email and password to sign in.');return;}const {data,error}=await lbClient.auth.signInWithPassword({email,password});if(error){lbNote('Sign-in failed: '+error.message);return;}lbUser=data.user;lbUpdateAuthUI();await lbPushScores(true);});
$('leaderboard-logout')?.addEventListener('click',async()=>{if(lbClient)await lbClient.auth.signOut();lbUser=null;lbUpdateAuthUI();lbNote('Signed out. Shared rankings remain visible.');});
$('leaderboard-player')?.addEventListener('change',()=>{if(lbUser)lbInit();});
function fmt(n){if(n<1000)return Math.floor(n).toLocaleString();const units=['K','M','B','T'];let i=-1;while(n>=1000&&i<units.length-1){n/=1000;i++;}return n.toFixed(n>=100?0:n>=10?1:2)+units[i];}
function cost(u){return Math.floor(u.base*Math.pow(u.growth,state.owned[u.id]));}
function buffMultiplier(){return (1+state.rebirths*0.25)*Math.pow(10,state.prestiges||0)*Math.pow(5,state.ascensions||0);}
function clickPower(){const seasonal=upgrades.filter(u=>u.kind==='click'&&u.id.startsWith(HOLIDAY+'_')).reduce((n,u)=>n+(state.owned[u.id]||0)*u.amount,0);const base={pea:1,repeater:3,threepeater:6,mega:15,shadow:5,greenshadow:7,electric:10,fire:8,snow:4,goo:6}[state.selectedPlant]||1;const level=state.plantLevels[state.selectedPlant]||0;const fertilizer=state.fertilizer[state.selectedPlant]||0;const sb=skillBuffs();return Math.floor((base+seasonal+state.owned.double+state.owned.repeater*5+state.owned.threepeater*12+level*({pea:2,repeater:5,threepeater:10,mega:25,shadow:6,greenshadow:8,electric:12,fire:10,snow:5,goo:7}[state.selectedPlant]||2)+sb.click)*Math.pow(1.05,fertilizer)*buffMultiplier()*sb.mult);}
const plantNames={pea:'Peashooter',repeater:'Repeater',threepeater:'Threepeater',mega:'Mega Gatling Pea',shadow:'Water Peashooter',greenshadow:'Shy Peashooter',electric:'Electric Peashooter',fire:'Fire Peashooter',snow:'Snow Pea',goo:'Plasma Peashooter'};
function renderSpecial(){const p=state.selectedPlant;const level=state.plantLevels[p]||0;const cost=Math.floor(100*Math.pow(2,level));$('special-upgrade-title').textContent=plantNames[p]+' training';$('special-upgrade-list').innerHTML='';const row=document.createElement('article');row.className='upgrade-item';row.innerHTML='<span class="upgrade-icon">⬆️</span><div class="upgrade-copy"><strong>'+plantNames[p]+' mastery · Level '+level+'</strong><small>Plant-specific power upgrade: +'+({pea:2,repeater:5,threepeater:10,mega:25,shadow:6,greenshadow:8,electric:12,fire:10,snow:5,goo:7}[p]||2)+' base click power per level.</small><span class="upgrade-owned">Applies only to '+plantNames[p]+'</span></div>';const btn=document.createElement('button');btn.className='upgrade-buy';btn.disabled=state.peas<cost;btn.innerHTML='<strong>'+fmt(cost)+' '+currencyName()+'</strong><small>Train plant</small>';btn.addEventListener('click',()=>{if(state.peas<cost)return;state.peas-=cost;state.plantLevels[p]++;checkAchievements();render();save();});row.append(btn);$('special-upgrade-list').append(row);$('gold-count').textContent=state.goldBars;$('buy-gold').disabled=state.peas<100;$('buy-fertilizer').disabled=state.goldBars<1;$('fertilizer-status').textContent=plantNames[p]+' fertilizer level: '+(state.fertilizer[p]||0)+". Each use permanently boosts this plant's click power by 5%.";}

function peaRate(){const seasonal=upgrades.filter(u=>u.kind==='passive'&&u.id.startsWith(HOLIDAY+'_')).reduce((n,u)=>n+(state.owned[u.id]||0)*u.amount,0);return (seasonal+state.owned.sunflower+state.owned.gatling*8+state.owned.megagatling*35)*buffMultiplier();}
function earn(n){n=Math.max(0,n);state.peas+=n;state.totalEarned+=n;}
function checkAchievements(){achievementDefs.forEach(a=>{if(!state.unlocked.includes(a.id)&&a.check(state)){state.unlocked.push(a.id);$('clicker-hint').textContent='🏆 Achievement unlocked: '+a.name+'!';}});}
function renderUpgrades(){
  const list=$('upgrade-list');
  list.innerHTML='';
  list.className='honeycomb upgrade-honey'; if(!document.getElementById('upgrade-info')){const p=document.createElement('p');p.id='upgrade-info';p.className='clicker-hint';p.textContent='Hover an upgrade to see what it does.';list.after(p);}
  upgrades.forEach(u=>{
    const c=cost(u), can=state.peas>=c, owned=state.owned[u.id]||0;
    const cell=document.createElement('button');
    cell.type='button';
    cell.className='hex-cell'+(owned>0?' owned':'');
    cell.disabled=!can;
    cell.title=u.name+' — '+u.desc+' | Owned: '+owned+' | Cost: '+fmt(c); cell.onmouseenter=()=>{const info=document.getElementById('upgrade-info'); if(info) info.textContent=u.name+': '+u.desc+' | Owned: '+owned+' | Next: '+fmt(c);};
    cell.innerHTML='<span style="font-size:16px;line-height:1">'+u.icon+'</span><span style="font-size:8px;margin-top:2px">'+u.name.split(' ')[0]+'</span><span style="font-size:7px;opacity:.7">'+fmt(c)+'</span>';
    cell.addEventListener('click',()=>{
      const current=cost(u);
      if(state.peas<current) return;
      state.peas-=current;
      state.owned[u.id]++;
      checkAchievements();
      render();
      save();
    });
    list.appendChild(cell);
  });
}

function ensureAchievementsVisible(){
  const list = document.getElementById('achievement-list');
  const panel = document.querySelector('.achievements-panel');
  if(panel && list){
    const stats = document.querySelector('.clicker-stats');
    if(stats && panel.compareDocumentPosition(stats) & Node.DOCUMENT_POSITION_FOLLOWING){
      stats.after(panel);
    }
  }
  renderAchievements();
}

function renderAchievements(){$('achievement-list').innerHTML='';achievementDefs.forEach(a=>{const unlocked=state.unlocked.includes(a.id);const card=document.createElement('div');card.className='achievement-card'+(unlocked?' unlocked':'');const badge=document.createElement('span');badge.className='achievement-badge';badge.textContent=unlocked?'✓':'🔒';const name=document.createElement('strong');name.textContent=a.name;const desc=document.createElement('small');desc.textContent=a.desc;card.append(badge,name,desc);$('achievement-list').append(card);});$('achievement-count').textContent=state.unlocked.length+' / '+achievementDefs.length+' UNLOCKED';}

const ZOMBIE_TYPES = {
  flag: {name:'Flag Zombie', img:'images/zombie-flag.png', hpMult:1.2},
  basic: {name:'Basic Zombie', img:'images/zombie.png', hpMult:1},
  cone: {name:'Conehead Zombie', img:'images/zombie-cone.png', hpMult:1.8},
  bucket: {name:'Buckethead Zombie', img:'images/zombie-bucket.png', hpMult:2.5},
  garg: {name:'Gargantuar', img:'images/zombie-gargantuar.png', hpMult:6}
};
function buildWave(stage){
  const basics = 2 + stage;
  const cones = 2 + Math.floor(stage / 2);
  const buckets = 2 + Math.floor(stage / 3);
  const wave = ['flag'];
  for(let i=0;i<basics;i++) wave.push('basic');
  for(let i=0;i<cones;i++) wave.push('cone');
  for(let i=0;i<buckets;i++) wave.push('bucket');
  wave.push('garg');
  return wave;
}
function currentZombie(){
  if(!state.wave || !state.wave.length) state.wave = buildWave(state.zombieStage);
  const idx = state.waveIndex || 0;
  const type = state.wave[idx] || 'basic';
  return ZOMBIE_TYPES[type] || ZOMBIE_TYPES.basic;
}

function renderZombie(){const z=currentZombie();const pct=Math.max(0,Math.min(100,state.zombieHp/state.zombieMaxHp*100));$('zombie-stage').textContent='WAVE '+state.zombieStage;$('zombie-health-fill').style.width=pct+'%';$('zombie-health-text').textContent=state.zombieHp+' / '+state.zombieMaxHp+' health';$('zombie-name').textContent=z.name;const av=$('zombie-avatar');if(av){const wasHit=av.classList.contains('zombie-hit');av.innerHTML='<img src="'+z.img+'" alt="'+z.name+'" style="width:100%;height:100%;object-fit:contain;filter:drop-shadow(0 4px 8px rgba(0,0,0,.5))">';if(wasHit)av.classList.add('zombie-hit');}}

function renderProgressionHoney(){
  let panel = document.getElementById('progression-honey');
  if(!panel){
    panel = document.createElement('section');
    panel.id = 'progression-honey';
    panel.className = 'panel-card';
    panel.innerHTML = '<div class="field-top"><div><p class="eyebrow">PROGRESSION</p><h2>Rebirth · Prestige · Ascension</h2><p class="panel-subtitle">Click a hex to progress. Costs are fixed.</p></div></div><div id="prog-grid" class="honeycomb" style="max-height:160px"></div><p id="prog-status" class="clicker-hint"></p>';
    const anchor = document.querySelector('.rebirth-panel') || document.querySelector('.clicker-layout');
    if(anchor) anchor.before(panel);
    // hide old panels
    document.querySelectorAll('.rebirth-panel,.prestige-panel,.ascension-panel').forEach(el=>el.style.display='none');
  }
  const grid = document.getElementById('prog-grid');
  grid.innerHTML = '';
  const items = [
    {id:'rebirth', icon:'🌱', name:'Rebirth', cost:5000000, have:state.peas, label:'peas', count:state.rebirths, action:()=>document.getElementById('rebirth-button')?.click()},
    {id:'prestige', icon:'🌟', name:'Prestige', cost:50000000, have:state.peas, label:'peas', count:state.prestiges, action:()=>document.getElementById('prestige-button')?.click()},
    {id:'ascension', icon:'⛰️', name:'Ascension', cost:500000000, have:state.peas, label:'peas', count:state.ascensions, action:()=>document.getElementById('ascension-button')?.click()}
  ];
  items.forEach(it=>{
    const cell = document.createElement('button');
    cell.type = 'button';
    cell.className = 'hex-cell'+(it.count>0?' owned':'');
    cell.disabled = it.have < it.cost;
    cell.title = it.name+' — cost '+fmt(it.cost)+' '+it.label+' — owned: '+it.count;
    cell.innerHTML = '<span style="font-size:18px">'+it.icon+'</span><span style="font-size:9px;margin-top:2px">'+it.name+'</span><span style="font-size:7px;opacity:.7">'+fmt(it.cost)+'</span>';
    cell.onclick = it.action;
    grid.appendChild(cell);
  });
  document.getElementById('prog-status').textContent = 'Rebirths: '+state.rebirths+' · Prestiges: '+state.prestiges+' · Ascensions: '+state.ascensions+' · Multiplier: x'+buffMultiplier().toLocaleString(undefined,{maximumFractionDigits:2});
}

function renderRebirth(){const btn=$('rebirth-button');btn.disabled=state.peas<100000;$('rebirth-count').textContent=String(state.rebirths);$('rebirth-status').textContent=state.peas<100000?'Need '+fmt(100000-state.peas)+' more peas. Price stays 100,000 peas every time.':'Ready! Rebirth costs 100,000 peas.';$('rebirth-buff-status').textContent='Rebirth buff: x'+buffMultiplier().toLocaleString(undefined,{maximumFractionDigits:2})+' total pea power ('+(state.rebirths*25)+'% from rebirths, plus prestige).';$('prestige-count').textContent=String(state.prestiges);$('prestige-button').disabled=state.rebirths<10;$('prestige-status').textContent=state.rebirths<10?'Need '+(10-state.rebirths)+' more rebirth'+(10-state.rebirths===1?'':'s')+'. Requirement is always 10 rebirths.':'Ready! Prestige resets this run and all rebirths for a permanent x10 buff.';$('prestige-buff-status').textContent='Prestige buff: x'+Math.pow(10,state.prestiges).toLocaleString()+' permanent pea power before ascension buffs. Next prestige makes it x'+Math.pow(10,state.prestiges+1).toLocaleString()+'.';$('ascension-count').textContent=String(state.ascensions);$('ascension-button').disabled=state.prestiges<100;$('ascension-status').textContent=state.prestiges<100?'Need '+(100-state.prestiges)+' more prestige'+(100-state.prestiges===1?'':'s')+'. Cost is fixed at 100 prestiges.':'READY! Ascend to reset all progress except ascensions.';$('ascension-buff-status').textContent='Ascension buff: x'+Math.pow(5,state.ascensions).toLocaleString()+' permanent multiplier to prestige power. Total permanent multiplier: x'+(Math.pow(10,state.prestiges)*Math.pow(5,state.ascensions)).toLocaleString()+'. Next ascension multiplies prestige power by another 5×.';}
function render(){ if(!state) return; const currency=currencyName();document.querySelectorAll('[data-currency-label]').forEach(el=>el.textContent=currency);const totalLabel=$('stat-total-label');if(totalLabel)totalLabel.textContent='Total '+currency;$('pea-count').textContent=fmt(state.peas);$('click-power').textContent=fmt(clickPower());$('pea-rate').textContent=fmt(peaRate());$('zombie-count').textContent=fmt(state.zombiesDefeated);$('click-reward').textContent=fmt(clickPower());renderUpgrades();renderSpecial();renderZombie();renderAchievements();renderRebirth();renderProgressionHoney();lbRenderLocal();lbSchedulePush();}

const PROJECTILES = {
  normal: {pea:'images/projectile-normal-pea.png', mega:'images/projectile-normal-mega.png'},
  halloween: {pea:'images/projectile-halloween-pea.png', mega:'images/projectile-halloween-mega.png'},
  christmas: {pea:'images/projectile-christmas-pea.png', mega:'images/projectile-christmas-mega.png'},
  easter: {pea:'images/projectile-easter-pea.png', mega:'images/projectile-easter-mega.png'},
  thanksgiving: {pea:'images/projectile-thanksgiving-pea.png', mega:'images/projectile-thanksgiving-mega.png'},
  spring: {pea:'images/projectile-spring-pea.png', mega:'images/projectile-spring-mega.png'},
  summer: {pea:'images/projectile-summer-pea.png', mega:'images/projectile-summer-mega.png'},
  birthday: {pea:'images/projectile-birthday-pea.png', mega:'images/projectile-birthday-mega.png'}
};
function spawnProjectile(isCrit){
  const set = PROJECTILES[HOLIDAY] || PROJECTILES.normal;
  const src = isCrit ? set.mega : set.pea;
  const el = document.createElement('img');
  el.src = src;
  el.className = 'pea-shot' + (isCrit ? ' crit' : '');
  el.alt = '';
  const clicker = $('pea-clicker');
  const zombie = $('zombie-avatar');
  if(!clicker || !zombie) return;
  const cr = clicker.getBoundingClientRect();
  const zr = zombie.getBoundingClientRect();
  el.style.left = (cr.left + cr.width/2) + 'px';
  el.style.top = (cr.top + cr.height/2) + 'px';
  el.style.setProperty('--dx', (zr.left + zr.width/2 - cr.left - cr.width/2) + 'px');
  el.style.setProperty('--dy', (zr.top + zr.height/2 - cr.top - cr.height/2) + 'px');
  document.body.appendChild(el);
  setTimeout(()=>el.remove(), 450);
}

function shootZombie(){
 if(state.spawnDelay) return;
 state.zombieHp-=Math.max(1,window._lastDamage||clickPower());
 const avatar=$('zombie-avatar');
 if(avatar){avatar.classList.remove('zombie-hit');void avatar.offsetWidth;avatar.classList.add('zombie-hit');}
 if(state.zombieHp<=0){
  state.zombiesDefeated++;
  const defeatedType=(state.wave&&state.wave[state.waveIndex||0])||'basic';
  const goldRanges={basic:[1,3],flag:[2,2],cone:[3,5],bucket:[5,8],garg:[8,12]};
  const range=goldRanges[defeatedType]||[1,3];
  const bars=range[0]+Math.floor(Math.random()*(range[1]-range[0]+1));
  state.goldBars+=bars;
  const bonus=Math.floor((10+state.zombieStage*5)*buffMultiplier());earn(bonus);
  state.waveIndex=(state.waveIndex||0)+1;
  if(!state.wave || state.waveIndex>=state.wave.length){state.zombieStage++;state.wave=buildWave(state.zombieStage);state.waveIndex=0;}
  state.spawnDelay=1200;
  $('zombie-status').textContent='🟨 Defeated! Dropped '+bars+' gold and '+fmt(bonus)+' bonus. Next zombie spawning...';
  setTimeout(()=>{
    state.spawnDelay=0;
    const next=currentZombie();
    state.zombieMaxHp=Math.floor(20*Math.pow(1.38,state.zombieStage-1)*next.hpMult);state.zombieHp=state.zombieMaxHp;
    renderZombie();
    $('zombie-status').textContent='🧟 '+next.name+' has spawned!';
  },1200);
 } else {$('zombie-status').textContent='💥 Pea hit! '+fmt(state.zombieHp)+' zombie health remaining.';}
}
if(!state){ try{ state=window.state=load(); }catch(e){ state=window.state=fresh(); } }
$('pea-clicker').addEventListener('click',()=>{
 try{
  if(!state) state=window.state=fresh();
  state.clicks++;
  const power=Math.max(1,clickPower());
  const isCrit=Math.random()<0.15; window._lastCrit=isCrit; if(isCrit) state.crits=(state.crits||0)+1;
  const finalPower=isCrit?Math.floor(power*2.5):power;
  window._lastDamage=finalPower;
  earn(finalPower);
  spawnProjectile(isCrit);
  shootZombie();
  const floater=document.createElement('span');
  floater.className='pea-floater'+(isCrit?' crit':'');
  floater.textContent=(isCrit?'CRIT ':'')+'+'+fmt(finalPower);
  const r=$('pea-clicker').getBoundingClientRect();
  floater.style.left=(r.left+r.width/2+ (Math.random()*40-20))+'px';
  floater.style.top=(r.top+40)+'px';
  document.body.appendChild(floater);
  setTimeout(()=>floater.remove(),700);
  $('pea-clicker').classList.remove('pop','shooting');
  void $('pea-clicker').offsetWidth;
  $('pea-clicker').classList.add('pop','shooting');
  checkAchievements();
  render();
  const pc=$("pea-count"); if(pc){pc.classList.remove("bump"); void pc.offsetWidth; pc.classList.add("bump");}
  save();
 }catch(e){console.error(e);$('clicker-hint').textContent='Click error: '+e.message;}
});
document.querySelectorAll('[data-plant]').forEach(btn=>btn.addEventListener('click',()=>{state.selectedPlant=btn.dataset.plant;document.querySelectorAll('[data-plant]').forEach(b=>b.classList.toggle('selected',b===btn));const images={pea:holidayPeaSrc(),repeater:'images/Repeater.png',threepeater:'images/Threepeater.png',mega:'images/MegaGatlingPea.png',shadow:'images/WaterPeashooter.png',greenshadow:'images/ShyPeashooter.png',electric:'images/ElectricPeashooter.png',fire:'images/FirePeashooter.png',snow:'images/SnowPea.png',goo:'images/PlasmaPeashooter.png'};$('pea-clicker-image').src=images[state.selectedPlant]||images.pea;$('pea-clicker-image').alt=btn.dataset.label; $('pea-clicker').setAttribute('aria-label','Tap '+btn.dataset.label+' to collect peas'); $('selected-plant-label').textContent=btn.dataset.label;save();}));
if($('buy-gold')){$('buy-gold').style.display='none';$('buy-gold').disabled=true;}
$('rebirth-button').addEventListener('click',()=>{if(state.peas<5000000)return;if(!confirm('Rebirth for 100,000 peas? Your peas and upgrades will reset, except Double Peashooter and Sunflower upgrades, which stay. Plant mastery, fertilizer, and gold bars will reset. This cannot be undone.'))return;state.peas=0;state.owned.repeater=0;state.owned.threepeater=0;state.owned.gatling=0;state.owned.megagatling=0;upgrades.filter(u=>u.id.startsWith(HOLIDAY+'_')).forEach(u=>state.owned[u.id]=0);state.plantLevels={pea:0,repeater:0,threepeater:0,mega:0,shadow:0,greenshadow:0,electric:0,fire:0,snow:0,goo:0};state.fertilizer={pea:0,repeater:0,threepeater:0,mega:0,shadow:0,greenshadow:0,electric:0,fire:0,snow:0,goo:0};state.goldBars=0;state.rebirths=(state.rebirths||0)+1;$('clicker-hint').textContent='🌱 Rebirth complete! All pea power is boosted by 25% per rebirth.';render();save();});
$('prestige-button').addEventListener('click',()=>{if(state.peas<50000000)return;if(!confirm('PRESTIGE? This costs 50,000,000 peas and resets ALL peas, all upgrades (including Double Peashooter and Sunflower), rebirths, plant mastery, fertilizer, and gold bars. You keep your prestige count and gain a permanent 10x pea-power multiplier. This cannot be undone.'))return;state.peas=0;state.rebirths=0;state.owned=Object.assign({double:0,sunflower:0,repeater:0,threepeater:0,gatling:0,megagatling:0},Object.fromEntries(upgrades.map(u=>[u.id,0])));state.plantLevels={pea:0,repeater:0,threepeater:0,mega:0,shadow:0,greenshadow:0,electric:0,fire:0,snow:0,goo:0};state.fertilizer={pea:0,repeater:0,threepeater:0,mega:0,shadow:0,greenshadow:0,electric:0,fire:0,snow:0,goo:0};state.goldBars=0;state.prestiges=(state.prestiges||0)+1;$('clicker-hint').textContent='🌟 PRESTIGE COMPLETE! Permanent pea power multiplied by 10.';render();save();});
$('ascension-button').addEventListener('click',()=>{if(state.peas<500000000)return;if(!confirm('ASCEND? This costs 500,000,000 peas and resets EVERYTHING in your game progress: peas, all upgrades, rebirths, prestiges, mastery, fertilizer, gold bars, achievements, zombie progress, and lifetime pea totals. Only your ascension count and audio preferences survive. You gain a permanent 5× multiplier to prestige power. This cannot be undone.'))return;const nextAscensions=(state.ascensions||0)+1;const keepMuted=state.muted,keepVolume=state.volume;const keepSkills=state.skills||{};state=window.state=fresh();state.ascensions=nextAscensions;state.muted=keepMuted;state.volume=keepVolume;state.skills=keepSkills;lastTick=Date.now();$('clicker-hint').textContent='⛰️ ASCENSION COMPLETE! All progress reset except ascensions. Your prestige power is now multiplied by 5×.';render();save();updateMusic();});

$('buy-fertilizer').addEventListener('click',()=>{if(state.goldBars<1)return;state.goldBars-=1;state.fertilizer[state.selectedPlant]=(state.fertilizer[state.selectedPlant]||0)+1;$('fertilizer-status').textContent=plantNames[state.selectedPlant]+' was fertilized! Click power increased by 5%.';render();save();});


const bonusState={next:Date.now()+30000,button:null};
function spawnHolidayBonus(){
 if(bonusState.button&&bonusState.button.isConnected)return;
 const mega=Math.random()<0.15,amount=mega?Math.floor(7500+Math.random()*5001):Math.floor(1000+Math.random()*6501);
 const b=document.createElement('button');b.type='button';b.className='holiday-bonus';b.innerHTML=mega?'⭐<small>MEGA BONUS</small>':'✨<small>BONUS</small>';
 b.setAttribute('aria-label',(mega?'Mega bonus':'Bonus')+' — collect '+amount+' '+currencyName());
 b.addEventListener('click',()=>{earn(amount);state.bonuses=(state.bonuses||0)+1;$('clicker-hint').textContent=(mega?'MEGA BONUS! ':'Bonus collected! ')+fmt(amount)+' '+currencyName()+' added.';b.remove();bonusState.button=null;render();save();bonusState.next=Date.now()+30000;});
 ($("pea-clicker")||document.body).append(b);bonusState.button=b;setTimeout(()=>{if(b.isConnected){b.remove();bonusState.button=null;}},18000);
}
setInterval(()=>{if(Date.now()>=bonusState.next)spawnHolidayBonus();},1000);

const audio=$('clicker-music');function updateMusic(){audio.volume=state.volume/100;audio.muted=state.muted;$('music-volume').value=state.volume;$('music-toggle').textContent=audio.paused?'▶ Play music':'Ⅱ Pause music';$('music-mute').textContent=state.muted?'🔇 Sound muted':'🔊 Sound on';$('music-mute').setAttribute('aria-pressed',String(state.muted));}
$('music-toggle').addEventListener('click',async()=>{if(audio.paused){try{await audio.play();audioReady=true;}catch(e){$('clicker-hint').textContent='Tap Play music again if your browser blocked playback.';}}else{audio.pause();}updateMusic();save();});
$('music-mute').addEventListener('click',()=>{state.muted=!state.muted;audio.muted=state.muted;updateMusic();save();});
$('music-volume').addEventListener('input',()=>{state.volume=Number($('music-volume').value);if(state.volume>0&&state.muted){state.muted=false;audio.muted=false;}audio.volume=state.volume/100;updateMusic();save();});
$('reset-game').addEventListener('click',()=>{if(!confirm('Reset all Peashooter Clicker progress on this browser? This cannot be undone.'))return;audio.pause();audio.currentTime=0;state=window.state=fresh();lastTick=Date.now();save();$('clicker-hint').textContent='Fresh lawn! Every tap earns peas.';$('zombie-status').textContent='Tap your Peashooter to fire. Each defeated zombie drops 1–8 gold bars.';render();updateMusic();});
audio.addEventListener('play',updateMusic);audio.addEventListener('pause',updateMusic);
const eventBanner=document.createElement('div');eventBanner.className='holiday-event-label';eventBanner.id='holiday-event-label';eventBanner.textContent=currencyName()+' · '+HOLIDAY.toUpperCase()+' EVENT — progress saved separately';document.querySelector('.clicker-hero')?.after(eventBanner);
const holidayPea={halloween:'images/peashooter-halloween.png',christmas:'images/peashooter-christmas.png',easter:'images/peashooter-easter.png',thanksgiving:'images/peashooter-thanksgiving.png',spring:'images/peashooter-spring.png',summer:'images/peashooter-summer.png',normal:'images/peashooter-normal.png',birthday:'images/peashooter-birthday.png'};
const plantImages={'pea':holidayPea[HOLIDAY]||'images/peashooter-normal.png','repeater':'images/Repeater.png','threepeater':'images/Threepeater.png','mega':'images/MegaGatlingPea.png',shadow:'images/WaterPeashooter.png',greenshadow:'images/ShyPeashooter.png',electric:'images/ElectricPeashooter.png',fire:'images/FirePeashooter.png',snow:'images/SnowPea.png',goo:'images/PlasmaPeashooter.png'};
state.selectedPlant='pea';$('selected-plant-label').textContent='Seasonal Peashooter';$('pea-clicker-image').src=holidayPeaSrc();$('pea-clicker-image').alt='Seasonal Peashooter';$('pea-clicker').setAttribute('aria-label','Tap Seasonal Peashooter to collect '+currencyName());
if(!state){ try{ state=window.state=load(); }catch(e){ state=window.state=fresh(); } }
function holidayPeaSrc(){
  return ({halloween:'images/peashooter-halloween.png',christmas:'images/peashooter-christmas.png',easter:'images/peashooter-easter.png',thanksgiving:'images/peashooter-thanksgiving.png',spring:'images/peashooter-spring.png',summer:'images/peashooter-summer.png',normal:'images/peashooter-normal.png',birthday:'images/peashooter-birthday.png'})[HOLIDAY]||'images/peashooter-normal.png';
}
audio.volume=state.volume/100;audio.muted=state.muted;updateMusic();render();ensureAchievementsVisible();lbInit();
setInterval(()=>{const now=Date.now();const elapsed=Math.min(5,(now-lastTick)/1000);lastTick=now;state.playTime=(state.playTime||0)+elapsed;const rate=peaRate();if(rate>0){earn(rate*elapsed);checkAchievements();render();save();}},1000);
})();

// === SKILL TREE ===
const SKILL_SECTIONS = [
  {id:'power', name:'Power', color:'#ff5555', icon:'⚔️'},
  {id:'speed', name:'Speed', color:'#55aaff', icon:'⚡'},
  {id:'wealth', name:'Wealth', color:'#ffcc33', icon:'💰'},
  {id:'defense', name:'Defense', color:'#55cc55', icon:'🛡️'},
  {id:'mystic', name:'Mystic', color:'#cc55ff', icon:'✨'},
  {id:'nature', name:'Nature', color:'#44cc88', icon:'🌿'},
  {id:'chaos', name:'Chaos', color:'#ff8844', icon:'🔥'},
  {id:'time', name:'Time', color:'#88ccff', icon:'⏳'},
  {id:'shadow', name:'Shadow', color:'#6666aa', icon:'🌑'},
  {id:'divine', name:'Divine', color:'#ffee88', icon:'🌟'},
  {id:'rebirth', name:'Rebirth', color:'#7dffb3', icon:'🌱', currency:'rebirths'},
  {id:'prestige', name:'Prestige', color:'#ffd700', icon:'🌟', currency:'prestiges'},
  {id:'ascension', name:'Ascension', color:'#c9a0ff', icon:'⛰️', currency:'ascensions'}
];
function makeSkills(){
  const skills = [];
  const words = {
    power:['Might','Force','Strike','Impact','Crush','Slam','Blast','Smash','Punch','Kick','Bash','Whack','Hit','Blow','Thrust','Lunge','Stab','Slash','Cleave','Rend','Maul','Pound','Hammer','Fist','Claw'],
    speed:['Swift','Quick','Fast','Rapid','Haste','Rush','Dash','Zoom','Flash','Bolt','Sprint','Race','Hurry','Agile','Nimble','Fleet','Brisk','Speedy','Prompt','Instant','Zip','Dart','Blink','Gale','Surge'],
    wealth:['Gold','Coin','Rich','Wealth','Loot','Treasure','Gain','Profit','Earn','Yield','Harvest','Reap','Collect','Gather','Hoard','Stash','Cache','Vault','Bank','Fortune','Bounty','Prize','Gem','Jewel','Mint'],
    defense:['Guard','Shield','Block','Ward','Armor','Protect','Defend','Resist','Endure','Fortify','Barrier','Wall','Cover','Shelter','Safe','Secure','Tough','Hardy','Sturdy','Solid','Aegis','Bulwark','Rampart','Keep','Hold'],
    mystic:['Arcane','Mystic','Magic','Spell','Enchant','Aura','Glow','Shine','Radiant','Divine','Holy','Sacred','Blessed','Charmed','Hexed','Cursed','Fated','Destined','Chosen','Marked','Rune','Sigil','Glyph','Oracle','Seer'],
    nature:['Root','Leaf','Bloom','Vine','Seed','Moss','Fern','Dew','Sun','Rain','Petal','Stem','Pod','Grass','Clover','Sprout','Bud','Thorn','Bark','Sap','Grove','Glade','Meadow','Briar','Willow'],
    chaos:['Flame','Ember','Ash','Rage','Fury','Storm','Bolt','Spark','Burn','Inferno','Blaze','Heat','Scorch','Wild','Frenzy','Burst','Flare','Ignite','Smolder','Pyre','Havoc','Mayhem','Riot','Wrath','Chaos'],
    time:['Hour','Minute','Second','Era','Age','Epoch','Moment','Instant','Past','Future','Now','Cycle','Loop','Tick','Tock','Span','Drift','Flow','Wait','Rush','Eon','Aeon','Chrono','Tempo','Pulse'],
    shadow:['Shade','Dark','Night','Void','Gloom','Dusk','Eclipse','Umbra','Phantom','Wraith','Specter','Haunt','Veil','Mist','Fog','Hush','Silent','Hidden','Lost','Deep','Abyss','Nether','Shade','Dread','Hollow'],
    divine:['Light','Grace','Bless','Holy','Saint','Angel','Halo','Glory','Pure','Sacred','Heaven','Star','Dawn','Hope','Faith','Mercy','Virtue','Noble','Radiant','Eternal','Seraph','Cherub','Ascend','Halo','Crown'],
    rebirth:['Sprout','Renew','Cycle','Return','Bloom','Regrow','Revive','Awaken','Refresh','Restart','Reborn','Seedling','Sapling','Budding','Fresh','New','Again','Loop','Turn','Phase','Epoch','Season','Spring','Green','Life'],
    prestige:['Star','Crown','Glory','Fame','Honor','Legend','Myth','Epic','Grand','Supreme','Elite','Prime','Apex','Peak','Summit','Zenith','Pinnacle','Noble','Royal','Regal','Majestic','Brilliant','Radiant','Shining','Golden'],
    ascension:['Rise','Climb','Soar','Ascend','Elevate','Transcend','Beyond','Higher','Above','Peak','Summit','Zenith','Apex','Ultra','Mega','Hyper','Super','Omega','Alpha','Eternal','Infinite','Boundless','Limitless','Divine','Celestial']
  };
  const mods = ['of Power','of Speed','of Wealth','of Guard','of Magic','of Growth','of Fury','of Time','of Shade','of Light','Prime','Core','Edge','Mark','Seal','Rune','Glyph','Token','Shard','Spark','Wave','Bond','Link','Node','Crest'];
  const kinds = [
    {k:'click', a:1, d:'+1 click power'},
    {k:'click', a:2, d:'+2 click power'},
    {k:'click', a:3, d:'+3 click power'},
    {k:'click', a:5, d:'+5 click power'},
    {k:'passive', a:1, d:'+1 peas/sec'},
    {k:'passive', a:2, d:'+2 peas/sec'},
    {k:'passive', a:3, d:'+3 peas/sec'},
    {k:'mult', a:0.02, d:'+2% all income'},
    {k:'mult', a:0.05, d:'+5% all income'},
    {k:'mult', a:0.08, d:'+8% all income'},
    {k:'crit', a:0.01, d:'+1% crit chance'},
    {k:'crit', a:0.02, d:'+2% crit chance'},
    {k:'crit', a:0.03, d:'+3% crit chance'},
    {k:'gold', a:0.03, d:'+3% gold drops'},
    {k:'gold', a:0.05, d:'+5% gold drops'},
    {k:'gold', a:0.08, d:'+8% gold drops'},
    {k:'xp', a:0.05, d:'+5% mastery'},
    {k:'xp', a:0.1, d:'+10% mastery'},
    {k:'xp', a:0.15, d:'+15% mastery'},
    {k:'click', a:4, d:'+4 click power'}
  ];
  SKILL_SECTIONS.forEach(sec=>{
    const w = words[sec.id];
    const count = sec.currency ? 250 : 100;
    for(let i=0;i<count;i++){
      const name = w[i % w.length] + ' ' + mods[Math.floor(i / w.length) % mods.length] + ' ' + (i+1);
      const ef = kinds[(i * 3 + sec.id.length) % kinds.length];
      skills.push({
        id: sec.id + '_' + i,
        section: sec.id,
        name: name,
        desc: ef.d + ' (' + sec.name + ')',
        kind: ef.k,
        amount: ef.a,
        cost: sec.currency ? 1 : Math.floor(400 * Math.pow(1.12, i)),
        currency: sec.currency || 'peas',
        icon: sec.icon
      });
    }
  });
  return skills;
}
const ALL_SKILLS = makeSkills();
function skillBuffs(){ let skills=[]; try{ skills=ALL_SKILLS||[]; }catch(e){ skills=[]; }
  const owned = state.skills || {};
  let click=0, passive=0, mult=1, crit=0, gold=0, xp=0;
  skills.forEach(sk=>{
    if(!owned[sk.id]) return;
    if(sk.kind==='click') click += sk.amount * 5;
    else if(sk.kind==='passive') passive += sk.amount * 5;
    else if(sk.kind==='mult') mult *= (1+sk.amount*4);
    else if(sk.kind==='crit') crit += sk.amount;
    else if(sk.kind==='gold') gold += sk.amount;
    else if(sk.kind==='xp') xp += sk.amount;
  });
  return {click, passive, mult, crit, gold, xp};
}
function renderSkillTree(){
  let panel = document.getElementById('skill-tree-panel');
  if(!panel){
    panel = document.createElement('section');
    panel.id = 'skill-tree-panel';
    panel.className = 'panel-card';
    panel.innerHTML = '<div class="field-top"><div><p class="eyebrow">SKILL TREE</p><h2>Permanent Skills</h2><p class="panel-subtitle">Honeycomb grid. Skills never reset except on full game reset.</p></div></div><div id="skill-sections" style="display:flex;gap:8px;flex-wrap:wrap;margin-bottom:12px"></div><div id="skill-grid" class="honeycomb"></div><p id="skill-info" class="clicker-hint">Hover or click a skill to see what it does.</p>';
    const anchor = document.querySelector('.clicker-stats') || document.querySelector('.clicker-hero') || document.querySelector('main') || document.body;
    anchor.after(panel);
  }
  const secBar = document.getElementById('skill-sections');
  secBar.innerHTML = '';
  SKILL_SECTIONS.forEach(sec=>{
    const b = document.createElement('button');
    b.type = 'button';
    b.textContent = sec.icon + ' ' + sec.name;
    b.style.cssText = 'padding:6px 10px;border-radius:8px;border:1px solid '+sec.color+';background:#111;color:#fff;cursor:pointer;font-size:12px';
    b.onclick = ()=>renderSkillGrid(sec.id);
    secBar.appendChild(b);
  });
  renderSkillGrid(SKILL_SECTIONS[0].id);
}
function renderSkillGrid(secId){
  const grid = document.getElementById('skill-grid');
  if(!grid) return;
  grid.innerHTML = '';
  const skills = ALL_SKILLS.filter(s=>s.section===secId);
  const owned = state.skills || {};
  skills.forEach(sk=>{
    const cell = document.createElement('button');
    cell.type = 'button';
    cell.title = sk.name + ': ' + sk.desc + ' — ' + sk.cost + ' ' + (sk.currency||'peas');
    cell.className='hex-cell'+(owned[sk.id]?' owned':''); cell.style.setProperty('--hex-color', owned[sk.id]?'#55ff55':'#666');
    cell.textContent = sk.icon + '\n' + sk.name.split(' ')[0];
    const cur = sk.currency || 'peas';
    const have = cur==='peas' ? state.peas : (state[cur]||0);
    cell.disabled = !!owned[sk.id] || have < sk.cost;
    cell.onmouseenter = ()=>{ const info=document.getElementById('skill-info'); if(info) info.textContent = sk.name+': '+sk.desc+' — costs '+sk.cost+' '+(sk.currency||'peas'); };
    cell.onclick = ()=>{
      const c = sk.currency || 'peas';
      const h = c==='peas' ? state.peas : (state[c]||0);
      if(h < sk.cost || owned[sk.id]) return;
      if(!confirm(sk.name+'\n\n'+sk.desc+'\n\nCost: '+sk.cost+' '+(sk.currency||'peas')+'\n\nBuy this skill?')) return;
      if(c==='peas') state.peas -= sk.cost; else state[c] = (state[c]||0) - sk.cost;
      $('clicker-hint').textContent = 'Unlocked '+sk.name+': '+sk.desc;
      state.skills = state.skills || {};
      state.skills[sk.id] = 1;
      save();
      render();
      renderSkillTree();
    };
    grid.appendChild(cell);
  });
}

if(document.readyState==='loading') document.addEventListener('DOMContentLoaded', renderSkillTree); else renderSkillTree();
