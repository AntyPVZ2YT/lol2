(() => {
  const THEME_KEY = 'antypvz2-theme';
  const ACCENT_KEY = 'antypvz2-accent';
  const BG_KEY = 'antypvz2-background';
  const allowed = new Set(['dark', 'oled', 'light', 'system', 'ocean', 'violet', 'sunset']);
  const palettes = {
    dark:  { bg:'#06150f', green:'#a8ff60', green2:'#66e83d', line:'#1c4932' },
    oled:  { bg:'#000000', green:'#f2c75c', green2:'#ffd978', line:'#3a2e12' },
    light: { bg:'#f4f8f4', green:'#278b36', green2:'#197b2b', line:'#c8d9c9' },
    system:{ bg:'#06150f', green:'#a8ff60', green2:'#66e83d', line:'#1c4932' },
    ocean: { bg:'#06121d', green:'#35d9ff', green2:'#12a9d5', line:'#17415a' },
    violet:{ bg:'#10091b', green:'#c58bff', green2:'#a75cff', line:'#493060' },
    sunset:{ bg:'#1b0c0b', green:'#ffbd4a', green2:'#ff754a', line:'#60342a' }
  };
  const root = document.documentElement;
  const read = (key, fallback) => { try { return localStorage.getItem(key) || fallback; } catch (_) { return fallback; } };
  const validColor = value => /^#[0-9a-f]{6}$/i.test(value || '');
  function apply() {
    let theme = read(THEME_KEY, 'oled'); if (!allowed.has(theme)) theme = 'oled';
    root.dataset.theme = theme;
    const systemLight = theme === 'system' && window.matchMedia && window.matchMedia('(prefers-color-scheme: light)').matches;
    const palette = theme === 'system' && systemLight ? palettes.light : (palettes[theme] || palettes.dark);
    root.style.setProperty('--bg', palette.bg);
    root.style.setProperty('--green', palette.green);
    root.style.setProperty('--green2', palette.green2);
    root.style.setProperty('--line', palette.line);
    const accent = read(ACCENT_KEY, '');
    if (validColor(accent)) {
      root.style.setProperty('--green', accent);
      root.style.setProperty('--green2', accent);
      root.style.setProperty('--user-accent', accent);
      root.dataset.customAccent = 'true';
    } else { root.style.removeProperty('--user-accent'); delete root.dataset.customAccent; }
    const bg = read(BG_KEY, '');
    if (validColor(bg)) root.style.setProperty('--bg', bg);
    const picker = document.querySelector('[data-theme-picker]'); if (picker) picker.value = theme;
    const accentPicker = document.querySelector('[data-accent-picker]'); if (accentPicker) accentPicker.value = validColor(accent) ? accent : palette.green;
    const bgPicker = document.querySelector('[data-background-picker]'); if (bgPicker) bgPicker.value = validColor(bg) ? bg : palette.bg;
    const meta = document.querySelector('meta[name="theme-color"]'); if (meta) meta.content = validColor(bg) ? bg : palette.bg;
  }
  function store(key, value) { try { if (value) localStorage.setItem(key, value); else localStorage.removeItem(key); } catch (_) {} }
  apply();
  if (window.matchMedia) {
    const systemPreference = window.matchMedia('(prefers-color-scheme: light)');
    if (systemPreference.addEventListener) systemPreference.addEventListener('change', () => { if (read(THEME_KEY, 'oled') === 'system') apply(); });
  }
  document.addEventListener('DOMContentLoaded', () => {
    const themePicker = document.querySelector('[data-theme-picker]');
    if (themePicker) themePicker.addEventListener('change', () => { if (allowed.has(themePicker.value)) { store(THEME_KEY, themePicker.value); apply(); } });
    const accentPicker = document.querySelector('[data-accent-picker]');
    if (accentPicker) accentPicker.addEventListener('input', () => { store(ACCENT_KEY, accentPicker.value); apply(); });
    document.querySelectorAll('[data-accent-preset]').forEach(button => button.addEventListener('click', () => { store(ACCENT_KEY, button.dataset.accentPreset); apply(); }));
    const bgPicker = document.querySelector('[data-background-picker]');
    if (bgPicker) bgPicker.addEventListener('input', () => { store(BG_KEY, bgPicker.value); apply(); });
    const resetBg = document.querySelector('[data-reset-background]');
    if (resetBg) resetBg.addEventListener('click', () => { store(BG_KEY, ''); apply(); });
  });
})();
