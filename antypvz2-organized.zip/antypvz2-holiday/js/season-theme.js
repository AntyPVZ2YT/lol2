(() => {
const easterSunday=y=>{const a=y%19,b=Math.floor(y/100),c=y%100,d=Math.floor(b/4),e=b%4,f=Math.floor((b+8)/25),g=Math.floor((b-f+1)/3),h=(19*a+b-d-g+15)%30,i=Math.floor(c/4),k=c%4,l=(32+2*e+2*i-h-k)%7,m=Math.floor((a+11*h+22*l)/451),mo=Math.floor((h+l-7*m+114)/31)-1,day=((h+l-7*m+114)%31)+1;return new Date(y,mo,day)};
function getSeason(d=new Date()){
 const y=d.getFullYear(),e=easterSunday(y),good=new Date(e);good.setDate(e.getDate()-2);
 if(d.getMonth()===11 && d.getDate()>=1 || d.getMonth()===0 && d.getDate()===1) return 'christmas';
 if(d>=good && d<=e) return 'easter';
 const oct1=new Date(y,9,1),firstMon=1+((8-oct1.getDay())%7),secondMon=firstMon+7;
 const thanksStart=new Date(y,9,secondMon-3),thanksEnd=new Date(y,9,secondMon+1);
 if(d>=thanksStart&&d<=thanksEnd) return 'thanksgiving';
 if(d.getMonth()===9) return 'halloween';
 if(d.getMonth()===2 || d.getMonth()===3) return 'spring';
 if(d.getMonth()>=4 && d.getMonth()<=7) return 'summer';
 return 'normal';
}
const palettes={
 normal:{accent:'#00ff66',accent2:'#66ffaa',text:'#f4fff8',deco:['🌿','🌱','💚','🍃','🟢']},
 halloween:{accent:'#ff5500',accent2:'#ffaa44',text:'#fff8f0',deco:['🎃','🦇','🍂','👻','🕸️']},
 christmas:{accent:'#ff2244',accent2:'#55ff99',text:'#fffafa',deco:['❄️','🎄','✨','🎁','⛄']},
 easter:{accent:'#ee55ee',accent2:'#ffaaee',text:'#fff8ff',deco:['🐰','🥚','🌸','🐣','🌷']},
 thanksgiving:{accent:'#ff6611',accent2:'#ffcc66',text:'#fffaf0',deco:['🍁','🦃','🌽','🍂','🥧']},
 spring:{accent:'#ff3399',accent2:'#ff99cc',text:'#fff5fb',deco:['🌸','🌷','🦋','🌼','🐝']},
 summer:{accent:'#ff5500',accent2:'#ffcc33',text:'#fffaf0',deco:['🌺','🏖️','☀️','🌴','🍉']},
 birthday:{accent:'#ff66cc',accent2:'#cc66ff',text:'#fff0fa',deco:['🎂','🎈','🎉','🎁','🥳']}
};

const OVERRIDE_KEY = 'antypvz2.themeOverride';
function getOverride(){ try { return localStorage.getItem(OVERRIDE_KEY) || ''; } catch(e){ return ''; } }
function setOverride(v){ try { if(v) localStorage.setItem(OVERRIDE_KEY, v); else localStorage.removeItem(OVERRIDE_KEY); } catch(e){} }
function getActiveSeason(){
  const ov = getOverride();
  if(ov === 'birthday') return 'birthday';
  return getSeason();
}
function overlappingThemes(d=new Date()){
  // Return array of themes that are currently active (for overlap detection)
  const y=d.getFullYear(),e=easterSunday(y),good=new Date(e);good.setDate(e.getDate()-2);
  const list=[];
  if(d.getMonth()===11 && d.getDate()>=1 || d.getMonth()===0 && d.getDate()===1) list.push('christmas');
  if(d>=good && d<=e) list.push('easter');
  const oct1=new Date(y,9,1),firstMon=1+((8-oct1.getDay())%7),secondMon=firstMon+7;
  const thanksStart=new Date(y,9,secondMon-3),thanksEnd=new Date(y,9,secondMon+1);
  if(d>=thanksStart&&d<=thanksEnd) list.push('thanksgiving');
  if(d.getMonth()===9) list.push('halloween');
  if(d.getMonth()===2 || d.getMonth()===3) list.push('spring');
  if(d.getMonth()>=4 && d.getMonth()<=7) list.push('summer');
  if(!list.length) list.push('normal');
  return list;
}

function apply(){
 const key=getActiveSeason();
 const p=palettes[key]||palettes.normal;
 const r=document.documentElement;
 r.dataset.season=key;
 r.style.setProperty('--season-accent', p.accent);
 r.style.setProperty('--season-accent2', p.accent2);
 r.style.setProperty('--season-text', p.text);
 r.style.setProperty('--green', p.accent);
 r.style.setProperty('--green2', p.accent2);
 // Overscroll lock
 r.style.overscrollBehavior='none';
 document.body.style.overscrollBehavior='none';
 document.body.style.background='#000';
 // Decorations
 let layer=document.getElementById('season-deco-layer');
 if(!layer){
  layer=document.createElement('div');
  layer.id='season-deco-layer';
  layer.setAttribute('aria-hidden','true');
  layer.style.cssText='position:fixed;inset:0;pointer-events:none;z-index:1;overflow:hidden';
  document.body.prepend(layer);
 }
 layer.innerHTML='';
 const spots=[[8,12],[22,78],[38,18],[55,82],[72,22],[88,70],[15,45],[62,38],[42,65],[80,15]];
 spots.forEach((s,i)=>{
  const el=document.createElement('span');
  el.textContent=p.deco[i%p.deco.length];
  el.style.cssText=`position:absolute;left:${s[0]}%;top:${s[1]}%;font-size:${18+ (i%5)*4}px;opacity:0.22;transform:rotate(${(i*37)%50-25}deg);user-select:none`;
  layer.appendChild(el);
 });
}
apply();
window.AntyHoliday={getSeason,getActiveSeason,setOverride,getOverride,overlappingThemes,apply};
})();