/*
 * AntyPVZ2 shared leaderboards configuration.
 * Replace the two placeholder strings with your Supabase project URL and
 * publishable key (older projects may call it the anon/public key).
 * This file is public in the website: NEVER put a service_role/secret key here.
 */
window.ANTYPVZ2_SUPABASE = {
  url: 'https://qyvzkkdectatmudbomuj.supabase.co',
  anonKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InF5dnpra2RlY3RhdG11ZGJvbXVqIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTI5NDU1OTUsImV4cCI6MjEwODUyMTU5NX0.aUctyaGbtaV_xrAAfCAAAxSNy293bis54m9vGUq_Dyw'
};
