(()=>{
'use strict';
const audio=document.getElementById('zen-garden-music');
const play=document.getElementById('zen-music-toggle');
const mute=document.getElementById('zen-music-mute');
const volume=document.getElementById('zen-music-volume');
if(!audio||!play||!mute||!volume)return;
audio.volume=Number(volume.value)/100;
function update(){play.textContent=audio.paused?'▶ Play music':'Ⅱ Pause music';mute.textContent=audio.muted?'🔇 Sound muted':'🔊 Sound on';mute.setAttribute('aria-pressed',String(audio.muted));}
play.addEventListener('click',async()=>{if(audio.paused){try{await audio.play();}catch(e){play.textContent='▶ Tap to play music';}}else{audio.pause();}update();});
mute.addEventListener('click',()=>{audio.muted=!audio.muted;update();});
volume.addEventListener('input',()=>{audio.volume=Number(volume.value)/100;if(audio.volume>0)audio.muted=false;update();});
audio.addEventListener('play',update);audio.addEventListener('pause',update);update();
})();
